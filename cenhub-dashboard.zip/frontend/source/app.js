(function ensureDashboardModeAttr() {
  const parts = window.location.pathname.replace(/^\/+|\/+$/g, '').split('/').filter(Boolean);
  if (parts[0] === 'login') {
    document.body.dataset.dashboardMode = 'login';
    delete document.body.dataset.clientSlug;
    return;
  }
  if (parts[0] === 'team') {
    document.body.dataset.dashboardMode = 'team';
    delete document.body.dataset.clientSlug;
    return;
  }
  if (parts[0] === 'admin') {
    document.body.dataset.dashboardMode = parts.length >= 2 ? 'admin' : 'hub';
    if (parts.length >= 2) document.body.dataset.clientSlug = parts[1];
    else delete document.body.dataset.clientSlug;
    return;
  }
  if (parts[0] && parts[0] !== 'index.html') {
    document.body.dataset.dashboardMode = 'client';
    document.body.dataset.clientSlug = parts[0];
  }
})();

const DASHBOARD_MODE = document.body.dataset.dashboardMode || 'client';
const IS_LOGIN_PAGE = DASHBOARD_MODE === 'login';
const IS_TEAM_PAGE = DASHBOARD_MODE === 'team';
const IS_ADMIN_HUB = DASHBOARD_MODE === 'hub';
const IS_ADMIN_CLIENT = DASHBOARD_MODE === 'admin';
const IS_CLIENT_VIEW = DASHBOARD_MODE === 'client';
const IS_PREVIEW = IS_CLIENT_VIEW && Boolean(new URLSearchParams(window.location.search).get('client'));
const IS_ADMIN = IS_ADMIN_HUB || IS_ADMIN_CLIENT || IS_TEAM_PAGE
  || new URLSearchParams(window.location.search).get('view') === 'admin';

const ADMIN_UI = IS_ADMIN_HUB || IS_ADMIN_CLIENT || IS_TEAM_PAGE || IS_ADMIN;
const LOADING_MSG = ADMIN_UI ? 'Loading dashboard data...' : 'Henter dashboard data...';
const RETRY_MSG = ADMIN_UI ? 'Try again' : 'Prøv igen';

(function setInitialLoadingMessage() {
  const el = document.getElementById('initial-loading-msg');
  if (el) el.textContent = LOADING_MSG;
})();

function resolveClientSlug() {
  if (document.body.dataset.clientSlug) return document.body.dataset.clientSlug;
  const parts = window.location.pathname.replace(/^\/+|\/+$/g, '').split('/').filter(Boolean);
  if (parts[0] === 'admin' && parts[1]) return parts[1];
  if (parts[0] && parts[0] !== 'admin' && parts[0] !== 'index.html') return parts[0];
  return new URLSearchParams(window.location.search).get('client') || 'suntech-nordic';
}

const CLIENT_SLUG = resolveClientSlug();
let tenantParams = {};
let facebookClientId = CLIENT_SLUG;
let setupAccount = null;
let setupPipelines = [];
let metricsModelChangeMode = false;

function esc(value) {
  return String(value ?? '')
    .replace(/&/g, '&amp;')
    .replace(/</g, '&lt;')
    .replace(/>/g, '&gt;')
    .replace(/"/g, '&quot;')
    .replace(/'/g, '&#39;');
}

function renderBrandTopbar(rightHtml = '') {
  return `
    <header class="brand-topbar">
      <div class="brand-topbar-left">
        <img class="brand-logo" src="/cenhub-logo-white.png" alt="Cenhub" width="167" height="41" />
      </div>
      ${rightHtml ? `<div class="brand-topbar-right">${rightHtml}</div>` : ''}
    </header>
  `;
}

function wrapDashboardShell(content) {
  return `<div class="dashboard-shell">${content}</div>`;
}

function showToast(message, type = 'info') {
  const host = document.getElementById('toast-host');
  if (!host) return;
  const toast = document.createElement('div');
  toast.className = `toast${type === 'error' ? ' toast--error' : type === 'success' ? ' toast--success' : ''}`;
  toast.textContent = message;
  host.appendChild(toast);
  setTimeout(() => toast.remove(), 4200);
}

function fmtDkk(value) {
  return new Intl.NumberFormat('da-DK', {
    minimumFractionDigits: 0,
    maximumFractionDigits: 0,
  }).format(Math.round(Number(value) || 0));
}

function fmtRevenueDkk(value) {
  const amount = Math.round(Number(value) || 0);
  if (amount >= 1000000) {
    const millions = amount / 1000000;
    const formatted = new Intl.NumberFormat('da-DK', {
      minimumFractionDigits: millions % 1 === 0 ? 0 : 2,
      maximumFractionDigits: 2,
    }).format(millions);
    return `${formatted}M kr`;
  }
  return `${fmtDkk(amount)} kr`;
}

function clientNeedsAction(status) {
  return Boolean(status && status !== 'ready' && status !== 'syncing');
}

function clientActionHint(status) {
  const hints = {
    syncing: 'Sync in progress...',
    needs_token: 'Action needed — add GHL token in Settings',
    needs_metrics_model: 'Action needed — choose metrics model in Settings',
    needs_pipelines: 'Action needed — map pipelines in Settings',
    needs_sync: 'Action needed — sync data from Settings or click Sync',
    needs_review: 'Action needed — review client setup in Settings',
    sync_error: 'Sync failed — open Settings and try again',
  };
  return hints[status] || 'Action needed — open Settings to finish setup';
}

function requestGhlUserData(timeoutMs = 8000) {
  return new Promise((resolve) => {
    if (window.self === window.top) {
      resolve(null);
      return;
    }

    const timer = setTimeout(() => {
      window.removeEventListener('message', onMessage);
      resolve(null);
    }, timeoutMs);

    function onMessage(event) {
      if (event.data?.message === 'REQUEST_USER_DATA_RESPONSE' && event.data.payload) {
        clearTimeout(timer);
        window.removeEventListener('message', onMessage);
        resolve(event.data.payload);
      }
    }

    window.addEventListener('message', onMessage);
    window.parent.postMessage({ message: 'REQUEST_USER_DATA' }, '*');
  });
}

async function resolveTenantParams() {
  const params = new URLSearchParams(window.location.search);

  if (IS_ADMIN_HUB) {
    return {};
  }

  if (IS_ADMIN_CLIENT || IS_CLIENT_VIEW) {
    return { client: CLIENT_SLUG };
  }

  if (params.get('client')) {
    return { client: params.get('client') };
  }

  const locationFromUrl = params.get('location_id') || params.get('locationId');
  if (locationFromUrl) {
    return { location_id: locationFromUrl };
  }

  return { client: CLIENT_SLUG };
}

let CLIENT_ACCESS_KEY = new URLSearchParams(window.location.search).get('key') || '';

function appendTenantParams(searchParams) {
  if (tenantParams.location_id) searchParams.set('location_id', tenantParams.location_id);
  else if (tenantParams.client) searchParams.set('client', tenantParams.client);
  if (CLIENT_ACCESS_KEY) searchParams.set('key', CLIENT_ACCESS_KEY);
}
const ADMIN_API_KEY_STORAGE = 'cenhub_admin_api_key';
let currentStaffUser = null;

function getAdminApiKey() {
  return localStorage.getItem(ADMIN_API_KEY_STORAGE) || '';
}

function redirectToLogin() {
  const next = `${window.location.pathname}${window.location.search}`;
  window.location.href = `/login?next=${encodeURIComponent(next)}`;
}

async function fetchStaffMe() {
  const response = await fetch('/api/auth/me', { credentials: 'include' });
  const data = await response.json().catch(() => ({}));
  if (!response.ok) return null;
  return data.user || null;
}

async function requireStaffAuth() {
  const user = await fetchStaffMe();
  if (!user) {
    redirectToLogin();
    return null;
  }
  currentStaffUser = user;
  return user;
}

async function adminFetch(path, options = {}) {
  const headers = {
    'Content-Type': 'application/json',
    ...(options.headers || {}),
  };
  const legacyKey = getAdminApiKey();
  if (legacyKey) headers['x-api-key'] = legacyKey;

  const response = await fetch(path, {
    ...options,
    headers,
    credentials: 'include',
  });
  const data = await response.json().catch(() => ({}));
  if (response.status === 401 && ADMIN_UI) {
    redirectToLogin();
    throw new Error(data.error || 'Unauthorized.');
  }
  if (!response.ok) {
    throw new Error(data.error || `Request failed (${response.status})`);
  }
  return data;
}

async function staffLogout() {
  try {
    await fetch('/api/auth/logout', { method: 'POST', credentials: 'include' });
  } catch {
    // ignore
  }
  window.location.href = '/login';
}

function isStaffAdmin() {
  return currentStaffUser?.role === 'admin';
}

function renderStaffUserMenu() {
  const user = currentStaffUser;
  if (!user) return '';
  return `
    <div class="staff-user-menu" id="staff-user-menu">
      <button type="button" class="staff-user-trigger" onclick="toggleStaffUserMenu(event)" aria-haspopup="menu" aria-expanded="false">
        <span class="staff-header-name">${esc(user.name || user.email)}</span>
        <span aria-hidden="true">▾</span>
      </button>
      <div class="staff-user-dropdown" id="staff-user-dropdown" hidden role="menu">
        <div class="staff-user-meta">${esc(user.email)}<br>${esc(user.role)}</div>
        <button type="button" role="menuitem" class="staff-user-menu-item" onclick="staffLogout()">Log out</button>
      </div>
    </div>
  `;
}

function renderStaffAdminChrome(activeTab) {
  if (!currentStaffUser) return '';
  const nav = `
    <nav class="staff-nav" aria-label="Admin navigation">
      <a href="/admin" class="staff-nav-link${activeTab === 'clients' ? ' is-active' : ''}">Clients</a>
      ${isStaffAdmin() ? `<a href="/team" class="staff-nav-link${activeTab === 'team' ? ' is-active' : ''}">Team</a>` : ''}
    </nav>
  `;
  return `
    <div class="staff-admin-chrome">
      ${nav}
      ${renderStaffUserMenu()}
    </div>
  `;
}

function toggleStaffUserMenu(event) {
  event.stopPropagation();
  const dropdown = document.getElementById('staff-user-dropdown');
  const trigger = event.currentTarget;
  if (!dropdown) return;
  const willOpen = dropdown.hidden;
  closeStaffUserMenu();
  if (willOpen) {
    dropdown.hidden = false;
    trigger?.setAttribute('aria-expanded', 'true');
  }
}

function closeStaffUserMenu() {
  const dropdown = document.getElementById('staff-user-dropdown');
  const trigger = document.querySelector('.staff-user-trigger');
  if (dropdown) dropdown.hidden = true;
  if (trigger) trigger.setAttribute('aria-expanded', 'false');
}

function formatStaffLastLogin(value) {
  if (!value) return 'Never';
  const date = new Date(value);
  if (Number.isNaN(date.getTime())) return '—';
  return date.toLocaleString('en-GB', {
    day: 'numeric',
    month: 'short',
    year: 'numeric',
    hour: '2-digit',
    minute: '2-digit',
  });
}

function renderStaffStatusBadge(status) {
  const label = status === 'active' ? 'Active' : status === 'pending' ? 'Pending' : 'Disabled';
  return `<span class="staff-status-badge status-${status}">${label}</span>`;
}

async function copyTextToClipboard(text, successMessage) {
  try {
    await navigator.clipboard.writeText(text);
    showToast(successMessage, 'success');
  } catch {
    showToast('Could not copy to clipboard', 'error');
  }
}

function renderTeamPage(users) {
  return `
    ${renderBrandTopbar(renderStaffAdminChrome('team'))}
    ${wrapDashboardShell(`
    <div class="page-hero admin-hub-hero">
      <h1>Team & access</h1>
      <p>Invite Censio staff, manage roles, and control who can access the admin workspace.</p>
    </div>
    <div class="team-page">
      <div class="panel">
        <div class="panel-title">Staff members</div>
        <div id="team-users-content">${renderStaffUsersTable(users)}</div>
      </div>
    </div>
    <div class="brand-footer">
      Dashboard by Cenhub · Holstebro
    </div>
    `)}
  `;
}

async function loadTeamPage() {
  const dashboard = document.getElementById('dashboard');
  const user = await requireStaffAuth();
  if (!user) return;
  if (!isStaffAdmin()) {
    window.location.href = '/admin';
    return;
  }

  dashboard.innerHTML = `
    ${renderBrandTopbar(renderStaffAdminChrome('team'))}
    ${wrapDashboardShell(`
      <div class="loading-state">
        <div class="spinner"></div>
        Loading team...
      </div>
    `)}`;

  try {
    const data = await adminFetch('/api/auth/users');
    dashboard.innerHTML = renderTeamPage(data.users || []);
  } catch (error) {
    dashboard.innerHTML = `
      ${renderBrandTopbar(renderStaffAdminChrome('team'))}
      ${wrapDashboardShell(`<div class="error-state" style="padding:24px">${esc(error.message)}</div>`)}
    `;
  }
}

async function reloadTeamUsersTable() {
  const container = document.getElementById('team-users-content');
  if (!container) return;
  const data = await adminFetch('/api/auth/users');
  container.innerHTML = renderStaffUsersTable(data.users || []);
}

function renderStaffUserActions(user) {
  const isSelf = currentStaffUser?.id === user.id;
  const statusAction = user.status === 'disabled'
    ? `<button class="admin-btn" type="button" onclick="updateStaffUser('${esc(user.id)}', { status: 'active' })">Enable</button>`
    : `<button class="admin-btn" type="button" ${isSelf ? 'disabled title="You cannot disable your own account"' : ''} onclick="updateStaffUser('${esc(user.id)}', { status: 'disabled' })">Disable</button>`;
  const inviteAction = user.status === 'pending' || !user.hasPassword
    ? `<button class="admin-btn" type="button" onclick="copyStaffInviteLink('${esc(user.id)}')">Copy invite link</button>`
    : `<button class="admin-btn" type="button" onclick="resetStaffUserPassword('${esc(user.id)}', true)">Reset password</button>`;
  const deleteAction = isSelf
    ? ''
    : `<button class="admin-btn card-menu-item--danger" type="button" onclick="deleteStaffUser('${esc(user.id)}')">Delete</button>`;

  return `
    <div class="staff-user-actions">
      ${statusAction}
      ${inviteAction}
      ${deleteAction}
    </div>
  `;
}

function renderStaffUserRoleSelect(user) {
  const isSelf = currentStaffUser?.id === user.id;
  return `
    <select
      class="staff-role-select"
      ${isSelf ? 'disabled title="You cannot change your own role here"' : ''}
      onchange="updateStaffUserRole('${esc(user.id)}', this.value)"
    >
      <option value="member" ${user.role === 'member' ? 'selected' : ''}>Member</option>
      <option value="admin" ${user.role === 'admin' ? 'selected' : ''}>Admin</option>
    </select>
  `;
}

function renderStaffUserCard(user) {
  return `
    <article class="staff-user-card">
      <div class="staff-user-card-header">
        <div class="staff-user-card-name">${esc(user.name || '—')}</div>
        <div class="staff-user-card-email">${esc(user.email)}</div>
      </div>
      <div class="staff-user-card-row">
        <div class="staff-user-card-meta-label">Role</div>
        ${renderStaffUserRoleSelect(user)}
      </div>
      <div class="staff-user-card-meta">
        <div>
          <div class="staff-user-card-meta-label">Status</div>
          ${renderStaffStatusBadge(user.status)}
        </div>
        <div>
          <div class="staff-user-card-meta-label">Last login</div>
          <div>${esc(formatStaffLastLogin(user.lastLoginAt))}</div>
        </div>
      </div>
      ${renderStaffUserActions(user)}
    </article>
  `;
}

function renderStaffUsersTable(users) {
  const rows = users.map((user) => `
      <tr>
        <td>${esc(user.name || '—')}<div style="color:var(--text-soft);font-size:12px">${esc(user.email)}</div></td>
        <td>${renderStaffUserRoleSelect(user)}</td>
        <td>${renderStaffStatusBadge(user.status)}</td>
        <td>${esc(formatStaffLastLogin(user.lastLoginAt))}</td>
        <td>${renderStaffUserActions(user)}</td>
      </tr>
    `).join('');

  const cards = users.map((user) => renderStaffUserCard(user)).join('');

  return `
    <div class="staff-users-table-wrap">
      <table class="staff-users-table staff-users-table--desktop">
        <thead>
          <tr><th>User</th><th>Role</th><th>Status</th><th>Last login</th><th>Actions</th></tr>
        </thead>
        <tbody>${rows || '<tr><td colspan="5">No staff users yet.</td></tr>'}</tbody>
      </table>
    </div>
    <div class="staff-users-cards staff-users-cards--mobile">
      ${cards || '<div class="note">No staff users yet.</div>'}
    </div>
    <div style="margin-top:20px">
      <div class="panel-title" style="margin-bottom:10px">Invite staff member</div>
      <div class="team-invite-row">
        <div class="auth-field" style="margin:0">
          <label for="new-staff-email">Email</label>
          <input id="new-staff-email" type="email" placeholder="name@company.dk" />
        </div>
        <div class="auth-field" style="margin:0">
          <label for="new-staff-name">Name</label>
          <input id="new-staff-name" type="text" placeholder="Full name" />
        </div>
        <div class="auth-field" style="margin:0">
          <label for="new-staff-role">Role</label>
          <select id="new-staff-role" class="staff-role-select">
            <option value="member">Member</option>
            <option value="admin">Admin</option>
          </select>
        </div>
        <button class="admin-btn admin-btn--primary" type="button" style="align-self:end" onclick="createStaffUserFromForm()">${ICON_PLUS} Invite</button>
      </div>
    </div>
  `;
}

async function createStaffUserFromForm() {
  const email = document.getElementById('new-staff-email')?.value?.trim();
  const name = document.getElementById('new-staff-name')?.value?.trim();
  const role = document.getElementById('new-staff-role')?.value === 'admin' ? 'admin' : 'member';
  if (!email) {
    showToast('Email is required.', 'error');
    return;
  }
  try {
    const data = await adminFetch('/api/auth/users', {
      method: 'POST',
      body: JSON.stringify({ email, name, role }),
    });
    if (data.setupUrl) {
      await copyTextToClipboard(data.setupUrl, 'Invite link copied to clipboard.');
    }
    if (IS_TEAM_PAGE) {
      await reloadTeamUsersTable();
    }
    showToast('Staff member invited.', 'success');
  } catch (error) {
    showToast(error.message, 'error');
  }
}

async function updateStaffUser(userId, patch) {
  try {
    await adminFetch(`/api/auth/users/${encodeURIComponent(userId)}`, {
      method: 'PATCH',
      body: JSON.stringify(patch),
    });
    if (IS_TEAM_PAGE) {
      await reloadTeamUsersTable();
    }
    showToast('User updated.', 'success');
  } catch (error) {
    showToast(error.message, 'error');
    if (IS_TEAM_PAGE) await reloadTeamUsersTable();
  }
}

async function updateStaffUserRole(userId, role) {
  await updateStaffUser(userId, { role: role === 'admin' ? 'admin' : 'member' });
}

async function deleteStaffUser(userId) {
  if (!window.confirm('Delete this staff member? This permanently removes their account and cannot be undone.')) {
    return;
  }
  try {
    await adminFetch(`/api/auth/users/${encodeURIComponent(userId)}`, {
      method: 'DELETE',
    });
    if (IS_TEAM_PAGE) {
      await reloadTeamUsersTable();
    }
    showToast('Staff member deleted.', 'success');
  } catch (error) {
    showToast(error.message, 'error');
  }
}

async function copyStaffInviteLink(userId) {
  try {
    const data = await adminFetch(`/api/auth/users/${encodeURIComponent(userId)}/reset-password`, {
      method: 'POST',
      body: '{}',
    });
    if (data.setupUrl) {
      await copyTextToClipboard(data.setupUrl, 'Invite link copied to clipboard.');
    }
  } catch (error) {
    showToast(error.message, 'error');
  }
}

async function resetStaffUserPassword(userId, copyOnly = false) {
  try {
    const data = await adminFetch(`/api/auth/users/${encodeURIComponent(userId)}/reset-password`, {
      method: 'POST',
      body: '{}',
    });
    if (data.setupUrl) {
      await copyTextToClipboard(
        data.setupUrl,
        copyOnly ? 'Reset link copied to clipboard.' : 'Password reset link generated.',
      );
    }
  } catch (error) {
    showToast(error.message, 'error');
  }
}

function renderLoginPage() {
  const params = new URLSearchParams(window.location.search);
  const token = params.get('token');
  const next = params.get('next') || '/admin';
  const saved = params.get('saved') === '1';
  const dashboard = document.getElementById('dashboard');
  const ICON_EYE = '<svg width="16" height="16" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round"><path d="M2 12s3.5-7 10-7 10 7 10 7-3.5 7-10 7-10-7-10-7z"/><circle cx="12" cy="12" r="3"/></svg>';
  const ICON_EYE_OFF = '<svg width="16" height="16" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round"><path d="M17.94 17.94A10.94 10.94 0 0112 19c-6.5 0-10-7-10-7a20.3 20.3 0 014.06-5.94M9.9 4.24A10.94 10.94 0 0112 5c6.5 0 10 7 10 7a20.3 20.3 0 01-3.17 4.49"/><path d="M1 1l22 22"/><path d="M14.12 14.12A3 3 0 009.88 9.88"/></svg>';
  const ICON_AUTH_LOCK = '<svg width="20" height="20" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round"><rect x="4.5" y="10.5" width="15" height="9" rx="2"/><path d="M8 10.5V7a4 4 0 018 0v3.5"/></svg>';

  function renderPasswordField(id, label, attrs = '') {
    return `
      <div class="auth-field">
        <label for="${id}">${label}</label>
        <div class="auth-password-wrap">
          <input id="${id}" type="password" ${attrs} />
          <button
            type="button"
            class="auth-password-toggle"
            aria-label="Show password"
            onclick="toggleAuthPassword('${id}', this)"
          >${ICON_EYE}</button>
        </div>
      </div>
    `;
  }

  if (token) {
    dashboard.innerHTML = `
      ${renderBrandTopbar()}
      ${wrapDashboardShell(`
      <div class="auth-page">
        <div class="auth-card">
          <div class="auth-card-header">
            <div class="auth-card-title-row">
              <div class="auth-card-icon" aria-hidden="true">${ICON_AUTH_LOCK}</div>
              <h1>Set your password</h1>
            </div>
            <p>Create a password for your Cenhub staff account. The link expires after 48 hours.</p>
          </div>
          <div id="auth-error" class="auth-error" style="display:none"></div>
          <div id="auth-success" class="auth-success" style="display:none"></div>
          ${renderPasswordField('set-password', 'New password', 'autocomplete="new-password" minlength="8" placeholder="At least 8 characters" oninput="updatePasswordStrength()" onkeydown="if(event.key===\'Enter\')submitSetPassword()"')}
          <div id="password-strength" class="password-strength" aria-live="polite"></div>
          ${renderPasswordField('set-password-confirm', 'Confirm password', 'autocomplete="new-password" minlength="8" placeholder="Repeat your password" onkeydown="if(event.key===\'Enter\')submitSetPassword()"')}
          <input id="password-token" type="hidden" value="${esc(token)}" />
          <button id="auth-submit-btn" class="admin-btn admin-btn--primary auth-submit" type="button" onclick="submitSetPassword()">Save password</button>
          <div class="auth-note"><a href="/login">Back to login</a></div>
        </div>
      </div>
      `)}
    `;
    initAuthPage('set-password');
    return;
  }

  dashboard.innerHTML = `
    ${renderBrandTopbar()}
    ${wrapDashboardShell(`
    <div class="auth-page">
      <div class="auth-card">
        <div class="auth-card-header">
          <div class="auth-card-title-row">
            <div class="auth-card-icon" aria-hidden="true">${ICON_AUTH_LOCK}</div>
            <h1>Staff login</h1>
          </div>
          <p>Manage client dashboards and admin settings.</p>
        </div>
        ${saved ? '<div class="auth-success">Password saved. Sign in with your new password.</div>' : ''}
        <div id="auth-error" class="auth-error" style="display:none"></div>
        <div id="auth-success" class="auth-success" style="display:none"></div>
        <div class="auth-field">
          <label for="login-email">Email</label>
          <input id="login-email" type="email" autocomplete="username" placeholder="you@company.dk" onkeydown="if(event.key==='Enter')document.getElementById('login-password')?.focus()" />
        </div>
        ${renderPasswordField('login-password', 'Password', 'autocomplete="current-password" placeholder="Enter your password" onkeydown="if(event.key===\'Enter\')submitStaffLogin()"')}
        <input id="login-next" type="hidden" value="${esc(next)}" />
        <button id="auth-submit-btn" class="admin-btn admin-btn--primary auth-submit" type="button" onclick="submitStaffLogin()">Sign in</button>
        <div class="auth-note">Forgot password? <a class="auth-help-link" href="mailto:?subject=Cenhub%20staff%20password%20reset">Contact your admin</a> for a new setup link.</div>
      </div>
    </div>
    `)}
  `;
  initAuthPage('login-email');
}

function initAuthPage(focusId) {
  const focusEl = document.getElementById(focusId);
  if (focusEl) {
    requestAnimationFrame(() => focusEl.focus({ preventScroll: true }));
  }
}

function toggleAuthPassword(inputId, button) {
  const input = document.getElementById(inputId);
  if (!input || !button) return;
  const show = input.type === 'password';
  input.type = show ? 'text' : 'password';
  button.setAttribute('aria-label', show ? 'Hide password' : 'Show password');
  button.innerHTML = show
    ? '<svg width="16" height="16" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round"><path d="M17.94 17.94A10.94 10.94 0 0112 19c-6.5 0-10-7-10-7a20.3 20.3 0 014.06-5.94M9.9 4.24A10.94 10.94 0 0112 5c6.5 0 10 7 10 7a20.3 20.3 0 01-3.17 4.49"/><path d="M1 1l22 22"/><path d="M14.12 14.12A3 3 0 009.88 9.88"/></svg>'
    : '<svg width="16" height="16" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round"><path d="M2 12s3.5-7 10-7 10 7 10 7-3.5 7-10 7-10-7-10-7z"/><circle cx="12" cy="12" r="3"/></svg>';
}

function setAuthSubmitLoading(isLoading, loadingText, defaultText) {
  const button = document.getElementById('auth-submit-btn');
  if (!button) return;
  button.disabled = isLoading;
  button.classList.toggle('is-loading', isLoading);
  button.textContent = isLoading ? loadingText : defaultText;
  document.querySelectorAll('.auth-card input').forEach((input) => {
    if (input.type !== 'hidden') input.disabled = isLoading;
  });
}

function updatePasswordStrength() {
  const password = document.getElementById('set-password')?.value || '';
  const el = document.getElementById('password-strength');
  if (!el) return;
  if (!password) {
    el.textContent = '';
    el.className = 'password-strength';
    return;
  }
  let score = 0;
  if (password.length >= 8) score += 1;
  if (password.length >= 12) score += 1;
  if (/[A-Z]/.test(password) && /[a-z]/.test(password)) score += 1;
  if (/\d/.test(password)) score += 1;
  const labels = ['Weak', 'Fair', 'Good', 'Strong'];
  const classes = ['is-weak', 'is-fair', 'is-good', 'is-strong'];
  const idx = Math.min(Math.max(score - 1, 0), 3);
  el.className = `password-strength ${classes[idx]}`;
  el.textContent = `Password strength: ${labels[idx]}`;
}

function showAuthSuccess(message) {
  const errorEl = document.getElementById('auth-error');
  const successEl = document.getElementById('auth-success');
  if (errorEl) errorEl.style.display = 'none';
  if (!successEl) return;
  successEl.textContent = message;
  successEl.style.display = message ? 'block' : 'none';
}

function showAuthError(message) {
  const el = document.getElementById('auth-error');
  const successEl = document.getElementById('auth-success');
  if (successEl && message) successEl.style.display = 'none';
  if (!el) return;
  el.textContent = message;
  el.style.display = message ? 'block' : 'none';
}

async function submitStaffLogin() {
  showAuthError('');
  const nextPath = document.getElementById('login-next')?.value || '/admin';
  const email = document.getElementById('login-email')?.value?.trim();
  const password = document.getElementById('login-password')?.value || '';
  if (!email || !password) {
    showAuthError('Email and password are required.');
    return;
  }
  setAuthSubmitLoading(true, 'Signing in…', 'Sign in');
  try {
    const response = await fetch('/api/auth/login', {
      method: 'POST',
      credentials: 'include',
      headers: { 'Content-Type': 'application/json' },
      body: JSON.stringify({ email, password }),
    });
    const data = await response.json().catch(() => ({}));
    if (!response.ok) {
      showAuthError(data.error || 'Login failed.');
      setAuthSubmitLoading(false, 'Signing in…', 'Sign in');
      return;
    }
    showAuthSuccess('Signed in. Redirecting…');
    window.setTimeout(() => {
      window.location.href = nextPath || '/admin';
    }, 450);
  } catch (error) {
    showAuthError(error.message || 'Login failed.');
    setAuthSubmitLoading(false, 'Signing in…', 'Sign in');
  }
}

async function submitSetPassword() {
  showAuthError('');
  const token = document.getElementById('password-token')?.value || '';
  const password = document.getElementById('set-password')?.value || '';
  const confirmPassword = document.getElementById('set-password-confirm')?.value || '';
  if (password.length < 8) {
    showAuthError('Password must be at least 8 characters.');
    return;
  }
  if (password !== confirmPassword) {
    showAuthError('Passwords do not match.');
    return;
  }
  setAuthSubmitLoading(true, 'Saving…', 'Save password');
  try {
    const response = await fetch('/api/auth/set-password', {
      method: 'POST',
      credentials: 'include',
      headers: { 'Content-Type': 'application/json' },
      body: JSON.stringify({ token, password, confirmPassword }),
    });
    const data = await response.json().catch(() => ({}));
    if (!response.ok) {
      showAuthError(data.error || 'Could not set password.');
      setAuthSubmitLoading(false, 'Saving…', 'Save password');
      return;
    }
    showAuthSuccess('Password saved. Redirecting to sign in…');
    window.setTimeout(() => {
      window.location.href = '/login?saved=1&next=/admin';
    }, 1200);
  } catch (error) {
    showAuthError(error.message || 'Could not set password.');
    setAuthSubmitLoading(false, 'Saving…', 'Save password');
  }
}

function statusLabel(status) {
  const labels = {
    ready: 'Ready',
    syncing: 'Syncing',
    needs_token: 'Needs token',
    needs_metrics_model: 'Needs metrics model',
    needs_pipelines: 'Needs pipelines',
    needs_sync: 'Needs sync',
    needs_review: 'Needs review',
    sync_error: 'Sync failed',
  };
  return labels[status] || status;
}

function formatRelativeSync(dateValue, status) {
  if (status === 'syncing') return 'Syncing now...';
  if (!dateValue) return 'Not synced yet';
  const diffMs = Date.now() - new Date(dateValue).getTime();
  const minutes = Math.round(diffMs / 60000);
  if (minutes < 2) return 'Synced just now';
  if (minutes < 60) return `Synced ${minutes} min ago`;
  const hours = Math.round(minutes / 60);
  if (hours < 24) return `Synced ${hours} hr ago`;
  return `Synced ${new Date(dateValue).toLocaleString('en-GB')}`;
}

const ICON_SEARCH = '<svg width="15" height="15" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round"><circle cx="11" cy="11" r="7"/><path d="M21 21l-4.35-4.35"/></svg>';
const ICON_PLUS = '<svg width="14" height="14" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2.25" stroke-linecap="round"><path d="M12 5v14M5 12h14"/></svg>';
const ICON_CALENDAR = '<svg width="15" height="15" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round"><rect x="3.5" y="5.5" width="17" height="15" rx="2"/><path d="M8 3.5v4M16 3.5v4M3.5 10.5h17"/></svg>';
const ICON_CHEVRON_LEFT = '<svg width="14" height="14" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2.25" stroke-linecap="round" stroke-linejoin="round"><path d="M15 6l-6 6 6 6"/></svg>';
const ICON_CHEVRON_RIGHT = '<svg width="14" height="14" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2.25" stroke-linecap="round" stroke-linejoin="round"><path d="M9 6l6 6-6 6"/></svg>';
const ICON_SYNC = '<svg width="14" height="14" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round"><path d="M21 12a9 9 0 11-2.64-6.36"/><path d="M21 3v6h-6"/></svg>';
const ICON_CHEVRON = '<svg width="16" height="16" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round"><path d="M6 9l6 6 6-6"/></svg>';
const ICON_CHART = '<svg width="15" height="15" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round"><path d="M3 3v18h18"/><path d="M7 14l4-4 3 3 5-6"/></svg>';

function clientInitials(name) {
  const words = String(name || '?').trim().split(/\s+/).filter(Boolean);
  if (!words.length) return '?';
  if (words.length === 1) return words[0].slice(0, 2).toUpperCase();
  return (words[0][0] + words[1][0]).toUpperCase();
}

function renderAdminHubPage(clients) {
  const count = clients.length;
  const adminActions = isStaffAdmin() ? `
          <button class="admin-btn" type="button" onclick="syncAllClients(this)">${ICON_SYNC} Sync all</button>
          <button class="admin-btn admin-btn--primary" type="button" onclick="focusAddClient()">${ICON_PLUS} Add client</button>
  ` : '';
  return `
    ${renderBrandTopbar(renderStaffAdminChrome('clients'))}
    ${wrapDashboardShell(`
    <div class="page-hero admin-hub-hero">
      <h1>Client administration</h1>
      <p>Manage dashboard accounts, sync GHL data, and preview client views.</p>
    </div>
    <div class="admin-hub">
      <div class="hub-toolbar-row">
        <div class="hub-search">
          ${ICON_SEARCH}
          <input id="hub-search" type="search" placeholder="Search clients..." oninput="filterHubCards()" />
        </div>
        <span class="hub-count" id="hub-count">${count} client${count === 1 ? '' : 's'}</span>
        <div class="hub-toolbar-actions">
          ${adminActions}
        </div>
      </div>
      <div class="client-grid" id="client-grid">
        ${count ? clients.map((client) => renderClientCard(client)).join('') : `<div class="hub-empty">${isStaffAdmin() ? 'No clients yet. Create your first client below.' : 'No clients yet.'}</div>`}
        <div class="hub-empty" id="hub-no-results" style="display:none">No clients match your search.</div>
      </div>
      ${isStaffAdmin() ? renderAddClientPanel() : ''}
    </div>
    <div class="brand-footer">
      Dashboard by Cenhub · Holstebro
    </div>
    `)}
  `;
}

function focusAddClient() {
  const panel = document.getElementById('add-client-panel');
  if (panel) panel.open = true;
  const input = document.getElementById('new-account-name');
  if (!input) return;
  input.scrollIntoView({ behavior: 'smooth', block: 'center' });
  setTimeout(() => input.focus({ preventScroll: true }), 350);
}

function copyAdminUrl(clientId) {
  const url = `${window.location.origin}/admin/${clientId}`;
  navigator.clipboard.writeText(url).then(
    () => showToast('Admin URL copied', 'success'),
    () => showToast('Could not copy URL', 'error'),
  );
}

function closeCardMenus() {
  document.querySelectorAll('.card-menu.open').forEach((menu) => menu.classList.remove('open'));
}

function toggleCardMenu(clientId, event) {
  event.stopPropagation();
  const menu = document.getElementById(`card-menu-${clientId}`);
  if (!menu) return;
  const willOpen = !menu.classList.contains('open');
  closeCardMenus();
  if (willOpen) menu.classList.add('open');
}

function renderCardMenu(clientId, accountName) {
  const label = accountName || clientId;
  const deleteAction = isStaffAdmin()
    ? `<button type="button" role="menuitem" class="card-menu-item--danger" onclick="closeCardMenus(); deleteClient('${clientId}');">Delete client</button>`
    : '';
  return `
    <div class="card-menu" id="card-menu-${clientId}" data-client-id="${clientId}">
      <button
        type="button"
        class="icon-btn card-menu-trigger"
        aria-label="More actions for ${esc(label)}"
        title="More actions"
        aria-haspopup="menu"
        onclick="toggleCardMenu('${clientId}', event)"
      >
        <svg width="16" height="16" viewBox="0 0 24 24" fill="currentColor" aria-hidden="true">
          <circle cx="12" cy="5" r="1.75"></circle>
          <circle cx="12" cy="12" r="1.75"></circle>
          <circle cx="12" cy="19" r="1.75"></circle>
        </svg>
      </button>
      <div class="card-menu-dropdown" role="menu">
        <button type="button" role="menuitem" onclick="copyAdminUrl('${clientId}'); closeCardMenus();">Copy admin URL</button>
        ${deleteAction}
      </div>
    </div>
  `;
}

function renderClientCard(client) {
  const kpis = client.previewKpis || {};
  const pipelineLabel = client.pipelineMode === '3-pipeline' ? '3 pipelines' : '2 pipelines';
  const needsAction = clientNeedsAction(client.status);
  return `
    <article class="client-card${needsAction ? ' client-card--needs-action' : ''}" data-client-id="${client.clientId}" data-search="${esc(`${client.accountName} ${client.clientId}`.toLowerCase())}">
      <div class="client-card-header">
        <span class="client-avatar" aria-hidden="true">${esc(clientInitials(client.accountName))}</span>
        <div class="client-card-title-block">
          <h3>${esc(client.accountName)}</h3>
          <div class="client-card-slug">/${client.clientId}</div>
        </div>
        ${renderCardMenu(client.clientId, client.accountName)}
      </div>
      <div class="client-card-meta">
        <span class="status-badge status-${client.status}">${statusLabel(client.status)}</span>
        <span class="client-card-meta-divider" aria-hidden="true">·</span>
        <span>${pipelineLabel}</span>
        <span class="client-card-meta-divider" aria-hidden="true">·</span>
        <span data-sync-meta>${formatRelativeSync(client.lastSyncAt, client.status)}</span>
      </div>
      ${needsAction ? `<p class="client-card-action-hint">${esc(clientActionHint(client.status))}</p>` : ''}
      ${kpis.totalLeads != null ? `
        <div class="client-card-stats">
          <div class="client-card-stat">
            <div class="client-card-stat-value">${fmtDkk(kpis.totalLeads)}</div>
            <div class="client-card-stat-label">Leads</div>
          </div>
          <div class="client-card-stat">
            <div class="client-card-stat-value">${fmtDkk(kpis.clientsWon)}</div>
            <div class="client-card-stat-label">Won</div>
          </div>
          <div class="client-card-stat">
            <div class="client-card-stat-value">${fmtRevenueDkk(kpis.wonRevenue)}</div>
            <div class="client-card-stat-label">Revenue</div>
          </div>
        </div>
      ` : ''}
      <div class="client-card-actions">
        <a class="admin-btn" href="/admin/${client.clientId}">Settings</a>
        <a class="admin-btn admin-btn--primary" href="/${encodeURIComponent(client.clientId)}" target="_blank" rel="noopener noreferrer" title="Open client dashboard">Dashboard</a>
        <button class="admin-btn admin-btn--secondary" type="button" onclick="syncClient('${client.clientId}', this)">${ICON_SYNC} Sync</button>
      </div>
    </article>
  `;
}

function filterHubCards() {
  const query = (document.getElementById('hub-search')?.value || '').trim().toLowerCase();
  let visible = 0;
  document.querySelectorAll('#client-grid .client-card').forEach((card) => {
    const match = !query || (card.dataset.search || '').includes(query);
    card.style.display = match ? '' : 'none';
    if (match) visible += 1;
  });
  const empty = document.getElementById('hub-no-results');
  if (empty) empty.style.display = query && !visible ? '' : 'none';
}

function renderAddClientPanel() {
  return `
    <details class="add-client-panel" id="add-client-panel">
      <summary class="add-client-summary">
        <h2>${ICON_PLUS} Add new client</h2>
        <span class="add-client-summary-hint">Click to expand</span>
      </summary>
      <p class="add-client-desc">Creates the account and opens the setup page where you pick the metrics model and connect GHL.</p>
      <div class="add-client-body">
        <div class="setup-grid setup-grid--3">
          <div class="field-group">
            <label for="new-account-name">Account name</label>
            <input id="new-account-name" type="text" placeholder="ScanTherm" oninput="suggestNewClientSlug()" />
          </div>
          <div class="field-group">
            <label for="new-client-slug">Admin slug</label>
            <input id="new-client-slug" type="text" placeholder="scantherm" oninput="checkNewClientSlug()" />
            <div id="slug-status" class="slug-status"></div>
          </div>
          <div class="field-group">
            <label for="new-location-id">GHL location ID</label>
            <input id="new-location-id" type="text" placeholder="Optional — can be added later" />
          </div>
        </div>
        <div class="setup-actions" style="border-top:0;padding-top:16px;margin-top:0">
          <div></div>
          <button class="admin-btn admin-btn--primary" type="button" onclick="createClient()">${ICON_PLUS} Create client</button>
        </div>
      </div>
    </details>
  `;
}

async function loadAdminHub() {
  const dashboard = document.getElementById('dashboard');
  const user = await requireStaffAuth();
  if (!user) return;

  dashboard.innerHTML = `
    ${renderBrandTopbar(renderStaffAdminChrome('clients'))}
    ${wrapDashboardShell(`
      <div class="loading-state">
        <div class="spinner"></div>
        Loading clients...
      </div>
    `)}`;

  try {
    const data = await adminFetch('/api/clients');
    dashboard.innerHTML = renderAdminHubPage(data.clients || []);
  } catch (error) {
    dashboard.innerHTML = `
      ${renderBrandTopbar(renderStaffAdminChrome('clients'))}
      ${wrapDashboardShell(`<div class="error-state" style="padding:24px">${esc(error.message)}</div>`)}
    `;
  }
}

let slugCheckTimer = null;

function suggestNewClientSlug() {
  const name = document.getElementById('new-account-name')?.value || '';
  const slugInput = document.getElementById('new-client-slug');
  if (!slugInput || slugInput.dataset.userEdited === 'true') return;
  slugInput.value = name.trim().toLowerCase().replace(/[^a-z0-9]+/g, '-').replace(/^-|-$/g, '');
  checkNewClientSlug();
}

function checkNewClientSlug() {
  const slugInput = document.getElementById('new-client-slug');
  if (slugInput) slugInput.dataset.userEdited = 'true';
  clearTimeout(slugCheckTimer);
  slugCheckTimer = setTimeout(async () => {
    const slug = document.getElementById('new-client-slug')?.value || '';
    const statusEl = document.getElementById('slug-status');
    if (!statusEl || !slug) {
      if (statusEl) statusEl.textContent = '';
      return;
    }
    try {
      const result = await adminFetch(`/api/clients/check-slug?slug=${encodeURIComponent(slug)}`);
      statusEl.className = `slug-status ${result.available ? 'ok' : 'bad'}`;
      statusEl.textContent = result.available
        ? `Available · ${result.adminUrl}`
        : `Unavailable (${result.reason || 'taken'})`;
    } catch (error) {
      statusEl.className = 'slug-status bad';
      statusEl.textContent = error.message;
    }
  }, 300);
}

async function createClient() {
  const accountName = document.getElementById('new-account-name')?.value?.trim();
  const clientId = document.getElementById('new-client-slug')?.value?.trim();
  const locationId = document.getElementById('new-location-id')?.value?.trim();
  if (!accountName || !clientId) {
    window.alert('Account name and slug are required.');
    return;
  }
  try {
    await adminFetch('/api/clients', {
      method: 'POST',
      body: JSON.stringify({ accountName, clientId, locationId: locationId || null }),
    });
    showToast('Client created', 'success');
    window.location.href = `/admin/${encodeURIComponent(clientId)}`;
  } catch (error) {
    showToast(error.message, 'error');
  }
}

let hubSyncPollTimer = null;
let hubSyncPendingIds = new Set();
let hubSyncPollStartedAt = 0;
let hubSyncBaselineAt = new Map();

function stopHubSyncPolling() {
  if (hubSyncPollTimer) {
    clearInterval(hubSyncPollTimer);
    hubSyncPollTimer = null;
  }
  hubSyncPendingIds = new Set();
  hubSyncPollStartedAt = 0;
  hubSyncBaselineAt = new Map();
}

function isClientSyncing(client) {
  return client.status === 'syncing' || client.lastSyncStatus === 'syncing';
}

function hubBatchStillPending(clients) {
  if (!hubSyncPendingIds.size) return false;
  const byId = new Map((clients || []).map((client) => [client.clientId, client]));
  for (const clientId of hubSyncPendingIds) {
    const client = byId.get(clientId);
    if (!client) continue;
    if (isClientSyncing(client)) return true;
    if (client.lastSyncStatus === 'error') continue;
    const baseline = hubSyncBaselineAt.get(clientId);
    if (baseline === client.lastSyncAt) return true;
  }
  return false;
}

async function pollHubSyncProgress() {
  if (!IS_ADMIN_HUB || !document.getElementById('client-grid')) {
    stopHubSyncPolling();
    return;
  }

  if (hubSyncPollStartedAt && Date.now() - hubSyncPollStartedAt > 15 * 60 * 1000) {
    stopHubSyncPolling();
    showToast('Some sync jobs are still running. Refresh the page in a minute.', 'error');
    return;
  }

  try {
    const data = await adminFetch('/api/clients');
    const clients = data.clients || [];
    updateHubCardsFromClients(clients);

    if (hubBatchStillPending(clients)) return;

    const pendingIds = new Set(hubSyncPendingIds);
    stopHubSyncPolling();
    const dashboard = document.getElementById('dashboard');
    if (dashboard) {
      dashboard.innerHTML = renderAdminHubPage(clients);
    }
    const failed = clients.filter((client) =>
      pendingIds.has(client.clientId) && client.lastSyncStatus === 'error',
    );
    if (failed.length) {
      showToast(`${failed.length} sync(s) failed`, 'error');
    } else {
      showToast('All clients synced', 'success');
    }
  } catch {
    // Keep polling while background jobs run.
  }
}

function startHubSyncPolling(clientIds = [], clients = []) {
  stopHubSyncPolling();
  hubSyncPendingIds = new Set(clientIds);
  hubSyncPollStartedAt = Date.now();
  hubSyncBaselineAt = new Map(
    (clients || [])
      .filter((client) => clientIds.includes(client.clientId))
      .map((client) => [client.clientId, client.lastSyncAt]),
  );
  markHubCardsSyncing(clientIds);
  pollHubSyncProgress();
  hubSyncPollTimer = setInterval(pollHubSyncProgress, 3000);
}
function markHubCardsSyncing(clientIds = []) {
  clientIds.forEach((clientId) => {
    const card = document.querySelector(`.client-card[data-client-id="${clientId}"]`);
    if (!card) return;
    const badge = card.querySelector('.status-badge');
    if (badge) {
      badge.className = 'status-badge status-syncing';
      badge.textContent = statusLabel('syncing');
    }
    const meta = card.querySelector('[data-sync-meta]');
    if (meta) meta.textContent = 'Syncing now...';
  });
}

function updateHubCardsFromClients(clients) {
  (clients || []).forEach((client) => {
    const card = document.querySelector(`.client-card[data-client-id="${client.clientId}"]`);
    if (!card) return;
    const badge = card.querySelector('.status-badge');
    if (badge) {
      badge.className = `status-badge status-${client.status}`;
      badge.textContent = statusLabel(client.status);
    }
    const meta = card.querySelector('[data-sync-meta]');
    if (meta) meta.textContent = formatRelativeSync(client.lastSyncAt, client.status);
  });
}

async function syncAllClients(button) {
  if (button) button.disabled = true;
  try {
    showToast('Syncing all clients...');
    const data = await adminFetch('/api/clients', {
      method: 'POST',
      body: JSON.stringify({ action: 'sync-all' }),
    });

    if (data.queued) {
      const count = data.count ?? (data.clientIds || []).length;
      showToast(`Syncing ${count} client${count === 1 ? '' : 's'} in background`, 'success');
      const hubData = await adminFetch('/api/clients');
      startHubSyncPolling(data.clientIds || [], hubData.clients || []);
      return;
    }

    const failed = (data.results || []).filter((row) => !row.success);
    if (failed.length) {
      showToast(`${failed.length} sync(s) failed`, 'error');
    } else {
      showToast('All clients synced', 'success');
    }
    await loadAdminHub();
  } catch (error) {
    showToast(error.message, 'error');
  } finally {
    if (button) button.disabled = false;
  }
}

async function deleteClient(clientId) {
  const label = clientId;
  const ok = window.confirm(
    `Delete "${label}" permanently?\n\nThis removes the account, GHL token, and all synced snapshot data. This cannot be undone.`,
  );
  if (!ok) return;

  const typed = window.prompt(`Type "${clientId}" to confirm deletion:`);
  if (typed !== clientId) {
    showToast('Deletion cancelled — slug did not match.', 'error');
    return;
  }

  try {
    await adminFetch(`/api/clients/${encodeURIComponent(clientId)}`, { method: 'DELETE' });
    showToast(`Deleted ${clientId}`, 'success');
    if (IS_ADMIN_HUB) {
      await loadAdminHub();
    } else {
      window.location.href = '/admin';
    }
  } catch (error) {
    showToast(error.message, 'error');
  }
}

async function syncClient(clientId, button) {
  if (button) {
    button.disabled = true;
    button.textContent = 'Syncing...';
  }
  try {
    await adminFetch(`/api/clients/${encodeURIComponent(clientId)}/sync`, { method: 'POST', body: '{}' });
    showToast('Sync completed', 'success');
    if (IS_ADMIN_HUB) await loadAdminHub();
    else if (IS_ADMIN_CLIENT) {
      await loadSetupAccount();
      if (accountCanPreviewDashboard(setupAccount)) loadDashboard(true, { background: true, forceFresh: true });
    }
    else loadDashboard(true, { background: true, forceFresh: true });
  } catch (error) {
    showToast(error.message, 'error');
  } finally {
    if (button) {
      button.disabled = false;
      const label = button.dataset.syncLabel || 'Sync';
      button.innerHTML = button.dataset.syncLabel ? `${ICON_SYNC} ${label}` : label;
    }
  }
}

function getMetricsModelLabels(account, pipelines = setupPipelines) {
  const pipelineMap = new Map((pipelines || []).map((pipeline) => [pipeline.id, pipeline.name]));
  if (account.dedupeEnabled) {
    const winName = pipelineMap.get(account.winPipelineId) || account.winPipelineId || '—';
    return {
      typeLabel: 'Funnel + deduplication',
      winLabel: `Win pipeline: ${winName}`,
    };
  }
  if (account.winPipelineId) {
    const winName = pipelineMap.get(account.winPipelineId) || account.winPipelineId;
    return {
      typeLabel: 'Simple (single win pipeline)',
      winLabel: `Win pipeline: ${winName}`,
    };
  }
  return {
    typeLabel: 'Simple (no deduplication)',
    winLabel: 'All won opportunities',
  };
}

const ICON_CHECK = '<svg width="14" height="14" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="3" stroke-linecap="round" stroke-linejoin="round"><path d="M20 6L9 17l-5-5"/></svg>';
const ICON_LAYER = '<svg width="18" height="18" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round"><path d="M12 3l9 5-9 5-9-5 9-5z"/><path d="M3 13l9 5 9-5"/></svg>';
const ICON_MERGE = '<svg width="18" height="18" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round"><circle cx="6" cy="6" r="2.4"/><circle cx="6" cy="18" r="2.4"/><circle cx="18" cy="15" r="2.4"/><path d="M6 8.4V15.6"/><path d="M8.2 6.4C14 6.4 14 12.6 15.8 13.4"/></svg>';
const ICON_TARGET = '<svg width="14" height="14" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round"><circle cx="12" cy="12" r="8"/><circle cx="12" cy="12" r="3"/></svg>';
const ICON_LOCK = '<svg width="14" height="14" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round"><rect x="4.5" y="10.5" width="15" height="9" rx="2"/><path d="M8 10.5V7a4 4 0 018 0v3.5"/></svg>';
const ICON_UNLOCK = '<svg width="14" height="14" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round"><rect x="4.5" y="10.5" width="15" height="9" rx="2"/><path d="M8 10.5V7a4 4 0 017.8-1.2"/></svg>';
const ICON_TAG = '<svg width="14" height="14" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round"><path d="M20.6 12.7L12.7 20.6a2 2 0 01-2.8 0l-7-7a2 2 0 010-2.8L10.8 3H19a2 2 0 012 2v7.7z"/><circle cx="15" cy="8" r="1.2"/></svg>';
const ICON_HASH = '<svg width="14" height="14" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round"><path d="M5 9h14M5 15h14M10 3L8 21M16 3l-2 18"/></svg>';
const ICON_EDIT = '<svg width="14" height="14" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round"><path d="M12 20h9"/><path d="M16.5 3.5a2.1 2.1 0 013 3L7 19l-4 1 1-4 12.5-12.5z"/></svg>';
const ICON_WARNING = '<svg width="16" height="16" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round"><path d="M10.3 3.9L2.6 18a1.5 1.5 0 001.3 2.2h16.2a1.5 1.5 0 001.3-2.2L13.7 3.9a1.5 1.5 0 00-3.4 0z"/><path d="M12 9v4"/><path d="M12 16.5h.01"/></svg>';


function renderMetricsModelPanel(account) {
  const labels = getMetricsModelLabels(account);
  const showWizard = !account.metricsModelSetAt || metricsModelChangeMode;
  const wizardClass = showWizard ? ' is-wizard' : ' is-locked';
  const initialMode = account.dedupeEnabled ? 'dedupe' : (account.winPipelineId ? 'pipeline' : 'simple');
  const lockedCopy = account.metricsModelLockedAt
    ? `Locked since ${new Date(account.metricsModelLockedAt).toLocaleDateString('en-GB')}`
    : 'Editable until first successful sync';
  const badgeClass = account.metricsModelLockedAt ? 'metrics-model-badge is-locked' : 'metrics-model-badge';

  if (!showWizard) {
    return `
      <div class="metrics-model-panel is-locked">
        <div class="metrics-model-header">
          <div class="metrics-model-heading">
            <h3 class="metrics-model-title">Metrics model</h3>
          </div>
          <span class="${badgeClass}">${account.metricsModelLockedAt ? ICON_LOCK : ICON_UNLOCK} ${account.metricsModelLockedAt ? 'Locked' : 'Editable'}</span>
        </div>
        <p class="metrics-model-copy">
          Defines how clients won, revenue, Bundlinje, ROAS, and won-revenue charts are calculated.
        </p>
        <div class="metrics-model-facts">
          <div class="metrics-model-fact is-config">
            <span class="metrics-model-fact-icon">${ICON_TAG}</span>
            <div class="metrics-model-fact-body">
              <div class="metrics-model-fact-label">Model</div>
              <div class="metrics-model-fact-value">${labels.typeLabel}</div>
            </div>
          </div>
          <div class="metrics-model-fact is-config">
            <span class="metrics-model-fact-icon">${ICON_TARGET}</span>
            <div class="metrics-model-fact-body">
              <div class="metrics-model-fact-label">Win source</div>
              <div class="metrics-model-fact-value">${labels.winLabel}</div>
            </div>
          </div>
          <div class="metrics-model-fact">
            <span class="metrics-model-fact-icon">${account.metricsModelLockedAt ? ICON_LOCK : ICON_UNLOCK}</span>
            <div class="metrics-model-fact-body">
              <div class="metrics-model-fact-label">Status</div>
              <div class="metrics-model-fact-value">${lockedCopy}</div>
            </div>
          </div>
          <div class="metrics-model-fact">
            <span class="metrics-model-fact-icon">${ICON_HASH}</span>
            <div class="metrics-model-fact-body">
              <div class="metrics-model-fact-label">Version</div>
              <div class="metrics-model-fact-value">v${account.metricsModelVersion || 1}</div>
            </div>
          </div>
        </div>
        <div class="metrics-model-actions">
          <button class="admin-btn" type="button" onclick="startMetricsModelChange()">${ICON_EDIT} Change metrics model</button>
        </div>
      </div>
    `;
  }

  return `
    <div class="metrics-model-panel${wizardClass}">
      <div class="metrics-model-header">
        <div class="metrics-model-heading">
          <h3 class="metrics-model-title">${metricsModelChangeMode ? 'Change metrics model' : 'Metrics model'}</h3>
        </div>
      </div>
      <p class="metrics-model-copy">How should wins and revenue be counted for this client?</p>
      <div class="metrics-option-cards">
        <label class="metrics-option-card">
          <input type="radio" name="metrics-model-type" value="simple" ${initialMode === 'simple' ? 'checked' : ''} onchange="onMetricsModelTypeChange()" />
          <span class="metrics-option-card-top">
            <span class="metrics-option-card-icon">${ICON_LAYER}</span>
            <span class="metrics-option-card-title">Simple</span>
            <span class="metrics-option-card-radio">${ICON_CHECK}</span>
          </span>
          <span class="metrics-option-card-desc">Every won deal counts, from any pipeline. For clients without duplicate opportunities.</span>
        </label>
        <label class="metrics-option-card">
          <input type="radio" name="metrics-model-type" value="dedupe" ${initialMode === 'dedupe' ? 'checked' : ''} onchange="onMetricsModelTypeChange()" />
          <span class="metrics-option-card-top">
            <span class="metrics-option-card-icon">${ICON_MERGE}</span>
            <span class="metrics-option-card-title">Funnel + dedup</span>
            <span class="metrics-option-card-radio">${ICON_CHECK}</span>
          </span>
          <span class="metrics-option-card-desc">Wins count from one win pipeline only (e.g. Eftersalg). Duplicates are merged by contact.</span>
        </label>
      </div>
      <div class="metrics-model-win-select" id="metrics-win-pipeline-wrap" style="${initialMode === 'dedupe' ? '' : 'display:none'}">
        ${renderPipelineSelect('metrics-win-pipeline', 'Win pipeline (required)', account.winPipelineId || account.afterSalesPipelineId, setupPipelines)}
      </div>
      ${metricsModelChangeMode ? `
        <div class="metrics-confirm-strip">
          <div class="metrics-confirm-strip-title">${ICON_WARNING} Applying this recalculates revenue, clients won and all charts</div>
          <div class="metrics-confirm-strip-row">
            <label class="metrics-confirm-check">
              <input id="metrics-acknowledge-impact" type="checkbox" onchange="updateMetricsApplyState()" />
              <span>I understand the numbers will change</span>
            </label>
            <input id="metrics-confirm-slug" type="text" placeholder="Type ${CLIENT_SLUG} to confirm" autocomplete="off" oninput="updateMetricsApplyState()" />
          </div>
        </div>
      ` : ''}
      <div class="metrics-model-actions">
        ${metricsModelChangeMode ? `<button class="admin-btn" type="button" onclick="cancelMetricsModelChange()">Cancel</button>` : ''}
        <button
          id="metrics-apply-btn"
          class="admin-btn ${metricsModelChangeMode ? 'admin-btn--danger-solid' : 'admin-btn--primary'}"
          type="button"
          onclick="saveMetricsModel()"
          ${metricsModelChangeMode ? 'disabled' : ''}
        >
          ${ICON_CHECK} ${metricsModelChangeMode ? 'Apply change' : 'Save metrics model'}
        </button>
      </div>
    </div>
  `;
}

function updateMetricsApplyState() {
  const btn = document.getElementById('metrics-apply-btn');
  if (!btn || !metricsModelChangeMode) return;
  const ack = Boolean(document.getElementById('metrics-acknowledge-impact')?.checked);
  const slug = document.getElementById('metrics-confirm-slug')?.value?.trim() || '';
  btn.disabled = !(ack && slug === CLIENT_SLUG);
}

function onMetricsModelTypeChange() {
  const mode = document.querySelector('input[name="metrics-model-type"]:checked')?.value;
  const wrap = document.getElementById('metrics-win-pipeline-wrap');
  if (wrap) wrap.style.display = mode === 'dedupe' ? '' : 'none';
}

async function saveMetricsModel() {
  const mode = document.querySelector('input[name="metrics-model-type"]:checked')?.value || 'simple';
  const dedupeEnabled = mode === 'dedupe';
  const winPipelineId = dedupeEnabled
    ? (document.getElementById('metrics-win-pipeline')?.value || null)
    : null;

  if (dedupeEnabled && !winPipelineId) {
    showToast('Select a win pipeline for deduplication mode.', 'error');
    return;
  }

  const payload = {
    dedupeEnabled,
    winPipelineId,
    afterSalesPipelineId: dedupeEnabled ? winPipelineId : undefined,
  };

  if (metricsModelChangeMode) {
    payload.confirmSlug = document.getElementById('metrics-confirm-slug')?.value?.trim() || '';
    payload.acknowledgeImpact = Boolean(document.getElementById('metrics-acknowledge-impact')?.checked);
  }

  try {
    await adminFetch(`/api/clients/${encodeURIComponent(CLIENT_SLUG)}/metrics-model`, {
      method: 'POST',
      body: JSON.stringify(payload),
    });
    metricsModelChangeMode = false;
    showToast('Metrics model saved', 'success');
    await loadSetupAccount();
    if (accountCanPreviewDashboard(setupAccount)) {
      loadDashboard(true, { background: true });
    }
  } catch (error) {
    showToast(error.message, 'error');
  }
}

function startMetricsModelChange() {
  metricsModelChangeMode = true;
  if (setupAccount) {
    const panel = document.getElementById('setup-panel-mount');
    if (panel) panel.innerHTML = renderClientSetupPanel(setupAccount);
  }
}

function cancelMetricsModelChange() {
  metricsModelChangeMode = false;
  if (setupAccount) {
    const panel = document.getElementById('setup-panel-mount');
    if (panel) panel.innerHTML = renderClientSetupPanel(setupAccount);
  }
}

function renderPipelineSelect(id, label, value, pipelines, hint = '') {
  return `
    <div class="field-group">
      <label for="${id}">${label}</label>
      <select id="${id}">
        <option value="">— Select pipeline —</option>
        ${pipelines.map((pipeline) => `
          <option value="${esc(pipeline.id)}" ${pipeline.id === value ? 'selected' : ''}>${esc(pipeline.name)}</option>
        `).join('')}
      </select>
      ${hint ? `<p class="field-hint">${esc(hint)}</p>` : ''}
    </div>
  `;
}

function getSetupProgressSteps(account) {
  return [
    {
      id: 'metrics',
      label: 'Metrics',
      done: Boolean(account.metricsModelSetAt),
    },
    {
      id: 'ghl',
      label: 'GHL',
      done: Boolean(account.hasGhlToken && account.locationId),
    },
    {
      id: 'pipelines',
      label: 'Pipelines',
      done: Boolean(account.newLeadsPipelineId && account.salesPipelineId),
    },
    {
      id: 'meta',
      label: 'Meta',
      done: account.metaSyncStatus === 'ok',
      partial: Boolean(account.metaAdAccountId && account.metaSyncStatus !== 'ok'),
    },
  ];
}

function renderSetupProgressStrip(account) {
  const steps = getSetupProgressSteps(account);
  const checkIcon = '<svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-linecap="round" stroke-linejoin="round" aria-hidden="true"><path d="M20 6L9 17l-5-5"/></svg>';
  return `
    <nav class="setup-progress" aria-label="Setup progress">
      ${steps.map((step, index) => {
        const stateClass = step.done ? ' is-done' : (step.partial ? ' is-partial' : '');
        const mark = step.done
          ? `<span class="setup-progress-mark">${checkIcon}</span>`
          : `<span class="setup-progress-mark">${index + 1}</span>`;
        return `
          <button type="button" class="setup-progress-step${stateClass}" onclick="scrollToSetupSection('${step.id}')">
            ${mark}
            <span class="setup-progress-label">${step.label}</span>
          </button>
        `;
      }).join('')}
    </nav>
  `;
}

function scrollToSetupSection(sectionId) {
  const target = document.getElementById(`setup-section-${sectionId}`);
  if (!target) return;
  target.scrollIntoView({ behavior: 'smooth', block: 'start' });
}

function renderMetaSetupSection(account) {
  return `
      <div class="setup-section" id="setup-section-meta">
        <div class="setup-section-info">
          <div class="setup-section-title">Meta / Facebook connection</div>
          <div class="setup-section-status">
            <span class="status-badge status-${account.metaSyncStatus === 'ok' ? 'ready' : account.metaSyncStatus === 'error' ? 'sync_error' : 'needs_sync'}">${account.metaSyncStatus === 'ok' ? 'Meta synced' : account.metaSyncStatus === 'error' ? 'Meta sync error' : 'Meta not synced'}</span>
            ${account.metaLastSyncedAt ? `<span class="setup-section-sync-time">Last Meta sync: ${formatRelativeSync(account.metaLastSyncedAt)}</span>` : ''}
            ${account.metaSyncError ? `<span class="setup-meta-sync-error">${esc(account.metaSyncError)}</span>` : ''}
          </div>
        </div>
        <div class="setup-section-content">
          <div class="setup-grid setup-grid--2">
            <div class="field-group">
              <label for="setup-meta-ad-account-id">Meta Ad Account ID (required for sync)</label>
              <input id="setup-meta-ad-account-id" type="text" value="${account.metaAdAccountId || ''}" placeholder="154139302 or act_154139302" />
            </div>
            <div class="field-group">
              <label for="setup-facebook-client-id">Facebook metrics client key</label>
              <input id="setup-facebook-client-id" type="text" value="${account.facebookClientId || account.clientId || ''}" placeholder="${esc(account.clientId)}" />
            </div>
            <div class="field-group">
              <label for="setup-meta-page-id">Meta Page ID (optional)</label>
              <input id="setup-meta-page-id" type="text" value="${account.metaPageId || ''}" />
            </div>
            <div class="field-group">
              <label for="setup-meta-pixel-id">Meta Pixel ID (optional)</label>
              <input id="setup-meta-pixel-id" type="text" value="${account.metaPixelId || ''}" />
            </div>
            <div class="field-group" style="grid-column:1/-1">
              <div class="field-label-row">
                <label for="setup-meta-system-token">Meta System User token (override — usually leave blank)</label>
                ${account.hasEnvMetaSystemUserToken ? '<span class="token-status-ok">Vercel env token set</span>' : '<span class="token-status-warn">No META_SYSTEM_USER_TOKEN on server</span>'}
                ${account.hasSavedMetaSystemUserToken ? '<span class="token-status-warn">Saved override in DB</span>' : ''}
              </div>
              <input id="setup-meta-system-token" type="password" placeholder="${account.hasSavedMetaSystemUserToken ? 'Leave blank to use Vercel env and clear saved override' : 'Uses META_SYSTEM_USER_TOKEN on Vercel when blank'}" autocomplete="off" />
            </div>
            <div class="field-group" style="grid-column:1/-1">
              <div class="field-label-row">
                <label for="setup-meta-page-token">Meta Page access token (optional)</label>
                ${account.hasMetaPageAccessToken ? '<span class="token-status-ok">Token configured</span>' : ''}
              </div>
              <input id="setup-meta-page-token" type="password" placeholder="${account.hasMetaPageAccessToken ? '••••••••  (saved — leave blank to keep)' : 'For future lead sync'}" autocomplete="off" />
            </div>
          </div>
          <div class="setup-actions-inline">
            <button class="admin-btn admin-btn--secondary" type="button" onclick="syncMetaMetricsClient('${CLIENT_SLUG}')">${ICON_SYNC} Sync Meta metrics</button>
            ${account.hasSavedMetaSystemUserToken ? `<button class="admin-btn admin-btn--ghost" type="button" onclick="clearMetaSystemUserToken('${CLIENT_SLUG}')">Clear saved token override</button>` : ''}
          </div>
        </div>
      </div>
  `;
}

function renderClientSetupPanel(account) {
  if (!IS_ADMIN_CLIENT || !account) return '';
  const setupDisabled = !account.metricsModelSetAt ? ' is-disabled' : '';
  return `
    <div class="setup-panel">
      <nav class="admin-breadcrumb">
        <a href="/admin">Admin</a> / ${esc(account.accountName)}
      </nav>
      <div class="setup-panel-header">
        <div class="setup-panel-identity">
          <span class="setup-avatar" aria-hidden="true">${esc(clientInitials(account.accountName))}</span>
          <div>
            <h2>${esc(account.accountName)}</h2>
            <div class="setup-meta">
              <span class="status-badge status-${account.status}">${statusLabel(account.status)}</span>
              <span class="setup-meta-divider">·</span>
              <span>${formatRelativeSync(account.lastSyncAt)}</span>
            </div>
          </div>
        </div>
        ${renderCardMenu(CLIENT_SLUG, account.accountName)}
      </div>
      ${renderSetupProgressStrip(account)}
      <div id="setup-section-metrics">
        ${renderMetricsModelPanel(account)}
      </div>

      <div class="setup-section${setupDisabled}" id="setup-section-ghl">
        <div class="setup-section-info">
          <div class="setup-section-title">GHL connection</div>
          <div class="setup-section-status">
            <span class="status-badge status-${account.status}">${statusLabel(account.status)}</span>
            ${account.lastSyncAt ? `<span class="setup-section-sync-time">Last GHL sync: ${formatRelativeSync(account.lastSyncAt, account.status)}</span>` : ''}
          </div>
        </div>
        <div class="setup-section-content">
          <div class="setup-grid setup-grid--2">
            <div class="field-group">
              <label for="setup-location-id">Location ID</label>
              <input id="setup-location-id" type="text" value="${account.locationId || ''}" />
            </div>
            <div class="field-group">
              <label for="setup-timezone">Timezone</label>
              <input id="setup-timezone" type="text" value="${account.timezone || 'Europe/Copenhagen'}" />
            </div>
            <div class="field-group" style="grid-column:1/-1">
              <div class="field-label-row">
                <label for="setup-ghl-token">GHL token</label>
                ${account.hasGhlToken ? '<span class="token-status-ok">Token configured</span>' : ''}
              </div>
              <input id="setup-ghl-token" type="password" placeholder="${account.hasGhlToken ? '••••••••  (saved — leave blank to keep)' : 'Paste private integration token'}" autocomplete="off" />
            </div>
          </div>
          <div class="setup-actions-inline">
            <button class="admin-btn admin-btn--secondary" type="button" data-sync-label="Sync GHL data" onclick="syncClient('${CLIENT_SLUG}', this)">${ICON_SYNC} Sync GHL data</button>
          </div>
        </div>
      </div>

      <div class="setup-section${setupDisabled}" id="setup-section-pipelines">
        <div class="setup-section-info">
          <div class="setup-section-title">Pipeline slots</div>
          <div class="setup-section-status">
            <span class="status-badge status-${setupPipelines.length ? 'ready' : 'needs_sync'}">${setupPipelines.length ? `${setupPipelines.length} pipeline(s) loaded` : 'Pipelines not fetched'}</span>
          </div>
        </div>
        <div class="setup-section-content">
          <div class="setup-grid setup-grid--3">
            ${renderPipelineSelect('setup-new-leads', 'New leads (required)', account.newLeadsPipelineId, setupPipelines)}
            ${renderPipelineSelect('setup-sales', 'Sales (required)', account.salesPipelineId, setupPipelines)}
            ${renderPipelineSelect('setup-after-sales', 'After-sales (optional)', account.afterSalesPipelineId, setupPipelines, 'Leave empty if there is no after-sales pipeline.')}
          </div>
          <div class="setup-actions-inline">
            <button class="admin-btn admin-btn--secondary" type="button" data-sync-label="Fetch pipelines from GHL" onclick="fetchSetupPipelines(false, this)">${ICON_SYNC} Fetch pipelines from GHL</button>
          </div>
        </div>
      </div>

      ${renderMetaSetupSection(account)}

      <div class="setup-actions setup-actions--sticky${setupDisabled}">
        <div class="setup-actions-group">
          <a class="admin-btn" href="/${encodeURIComponent(CLIENT_SLUG)}" target="_blank" rel="noopener noreferrer">${ICON_CHART} Open dashboard</a>
        </div>
        <div class="setup-save-group">
          <p class="setup-save-hint">Changes apply when you click Save changes.</p>
          <label class="setup-ready-toggle">
            <input id="setup-ready-ghl" type="checkbox" ${account.readyForGhl ? 'checked' : ''} />
            <span>Ready for GHL iframe</span>
          </label>
          <button class="admin-btn admin-btn--primary" type="button" onclick="saveSetupAccount()">${ICON_CHECK} Save changes</button>
        </div>
      </div>
    </div>
  `;
}

function accountCanPreviewDashboard(account) {
  if (!account) return false;
  return Boolean(account.hasGhlToken || account.lastSyncAt);
}

function renderAdminSetupPlaceholder() {
  return `
    <div class="note admin-setup-placeholder">
      Save a GHL token and location ID above, then sync to preview dashboard data here.
    </div>
  `;
}

function renderAdminClientShell() {
  const dashboard = document.getElementById('dashboard');
  const emptyFilters = { pipelines: [], statuses: [], sources: [], assignees: [], dateFields: [] };
  dashboard.innerHTML = `
    ${renderBrandTopbar(`${renderStaffAdminChrome('clients')}<a class="admin-topbar-link" href="/admin">Clients</a>`)}
    ${wrapDashboardShell(`
    <div id="setup-panel-mount">
      <div class="loading-state" style="padding:24px">
        <div class="spinner"></div>
        Loading setup...
      </div>
    </div>
    <details class="panel admin-preview-section">
      <summary>${ICON_CHART} Dashboard preview <span style="color:var(--text-soft);font-weight:500">· advanced filters</span><span class="summary-chevron">${ICON_CHEVRON}</span></summary>
      ${renderAdminFiltersPanel(emptyFilters)}
      ${renderAdminDisplayOptions(false)}
      <div class="content-area" id="dashboard-content">
        ${renderAdminSetupPlaceholder()}
      </div>
    </details>
    `)}
  `;
}

async function initAdminClientPage() {
  const user = await requireStaffAuth();
  if (!user) return;
  renderAdminClientShell();
  try {
    await loadSetupAccount();
  } catch (error) {
    const panel = document.getElementById('setup-panel-mount');
    if (panel) {
      panel.innerHTML = `<div class="note" style="padding:24px">${esc(error.message)}</div>`;
    }
    return;
  }

  if (accountCanPreviewDashboard(setupAccount)) {
    ensureChartsVisible();
    loadDashboard(true);
  }
}

async function loadSetupAccount() {
  if (!IS_ADMIN_CLIENT) return;
  try {
    const data = await adminFetch(`/api/clients/${encodeURIComponent(CLIENT_SLUG)}`);
    setupAccount = data.account;
    if (setupAccount.accessKey && !CLIENT_ACCESS_KEY) {
      CLIENT_ACCESS_KEY = setupAccount.accessKey;
    }
    if (setupAccount.newLeadsPipelineId && !setupPipelines.length) {
      await fetchSetupPipelines(true);
    }
    const panel = document.getElementById('setup-panel-mount');
    if (panel) panel.innerHTML = renderClientSetupPanel(setupAccount);
  } catch (error) {
    const panel = document.getElementById('setup-panel-mount');
    if (panel) {
      panel.innerHTML = `<div class="note" style="padding:24px">${esc(error.message)}</div>`;
    }
    showToast(error.message, 'error');
    throw error;
  }
}

async function fetchSetupPipelines(silent = false, button = null) {
  if (button) {
    button.disabled = true;
    button.textContent = 'Fetching...';
  }
  try {
    const data = await adminFetch(`/api/clients/${encodeURIComponent(CLIENT_SLUG)}/sync-pipelines`, {
      method: 'POST',
      body: '{}',
    });
    setupPipelines = data.pipelines || [];
    if (!silent) showToast(`${setupPipelines.length} pipeline(s) loaded`, 'success');
    await loadSetupAccount();
  } catch (error) {
    showToast(error.message, 'error');
  } finally {
    if (button) {
      button.disabled = false;
      const label = button.dataset.syncLabel || 'Fetch pipelines from GHL';
      button.innerHTML = `${ICON_SYNC} ${label}`;
    }
  }
}

function collectMetaSetupPayload() {
  const payload = {
    metaAdAccountId: document.getElementById('setup-meta-ad-account-id')?.value?.trim() || null,
    metaPageId: document.getElementById('setup-meta-page-id')?.value?.trim() || null,
    metaPixelId: document.getElementById('setup-meta-pixel-id')?.value?.trim() || null,
    facebookClientId: document.getElementById('setup-facebook-client-id')?.value?.trim() || null,
  };
  const metaSystemToken = document.getElementById('setup-meta-system-token')?.value?.trim();
  if (metaSystemToken) payload.metaSystemUserToken = metaSystemToken;
  const metaPageToken = document.getElementById('setup-meta-page-token')?.value?.trim();
  if (metaPageToken) payload.metaPageAccessToken = metaPageToken;
  return payload;
}

async function clearMetaSystemUserToken(slug) {
  try {
    await adminFetch(`/api/clients/${encodeURIComponent(slug)}`, {
      method: 'PUT',
      body: JSON.stringify({ clearMetaSystemUserToken: true }),
    });
    showToast('Saved Meta token override cleared — using Vercel env token', 'success');
    await loadSetupAccount();
  } catch (error) {
    showToast(error.message, 'error');
  }
}

async function saveSetupAccount() {
  try {
    const payload = {
      locationId: document.getElementById('setup-location-id')?.value?.trim() || null,
      timezone: document.getElementById('setup-timezone')?.value?.trim() || 'Europe/Copenhagen',
      newLeadsPipelineId: document.getElementById('setup-new-leads')?.value || null,
      salesPipelineId: document.getElementById('setup-sales')?.value || null,
      afterSalesPipelineId: document.getElementById('setup-after-sales')?.value || null,
      readyForGhl: Boolean(document.getElementById('setup-ready-ghl')?.checked),
      ...collectMetaSetupPayload(),
    };
    const token = document.getElementById('setup-ghl-token')?.value?.trim();
    if (token) payload.ghlToken = token;
    await adminFetch(`/api/clients/${encodeURIComponent(CLIENT_SLUG)}`, {
      method: 'PUT',
      body: JSON.stringify(payload),
    });
    showToast('Account saved', 'success');
    await loadSetupAccount();
    if (accountCanPreviewDashboard(setupAccount)) {
      loadDashboard(true);
    }
  } catch (error) {
    showToast(error.message, 'error');
  }
}

async function syncMetaMetricsClient(slug) {
  try {
    const metaPayload = collectMetaSetupPayload();
    if (!metaPayload.metaAdAccountId) {
      showToast('Enter a Meta Ad Account ID first.', 'error');
      return;
    }
    showToast('Saving Meta settings and syncing…', 'info');
    const metaSystemToken = document.getElementById('setup-meta-system-token')?.value?.trim();
    if (!metaSystemToken) metaPayload.clearMetaSystemUserToken = true;
    const result = await adminFetch(`/api/clients/${encodeURIComponent(slug)}/sync-meta`, {
      method: 'POST',
      body: JSON.stringify(metaPayload),
    });
    if (result.skipped) {
      showToast(result.reason || 'Meta sync skipped', 'error');
    } else {
      let msg = 'Meta metrics synced';
      if (result.tokenSource) msg += ` (${result.tokenSource} token)`;
      if (result.ignoredAccountOverride) msg += ' — cleared invalid saved token override';
      showToast(msg, 'success');
    }
    await loadSetupAccount();
    if (accountCanPreviewDashboard(setupAccount)) {
      loadDashboard(true);
    }
  } catch (error) {
    showToast(error.message, 'error');
    await loadSetupAccount();
  }
}

(function initDashboardCharts(global) {
  const PALETTE = ['#ff6a00', '#138b53', '#0085f2', '#dc640a', '#833b08', '#a07868', '#ff9147', '#6b5348'];
  const STATUS_COLORS = { open: '#0085f2', won: '#138b53', lost: '#dc640a', abandoned: '#a07868' };

  function isoWeekKeyToLocalDates(weekKey) {
    const match = String(weekKey).match(/^(\d{4})-W(\d{2})$/);
    if (!match) return null;

    const isoYear = Number(match[1]);
    const isoWeek = Number(match[2]);
    const jan4 = new Date(Date.UTC(isoYear, 0, 4));
    const jan4Day = jan4.getUTCDay() || 7;
    const mondayWeek1 = new Date(jan4);
    mondayWeek1.setUTCDate(jan4.getUTCDate() - jan4Day + 1);

    const monday = new Date(mondayWeek1);
    monday.setUTCDate(mondayWeek1.getUTCDate() + (isoWeek - 1) * 7);

    const thursday = new Date(monday);
    thursday.setUTCDate(monday.getUTCDate() + 3);

    return {
      monday: new Date(monday.getUTCFullYear(), monday.getUTCMonth(), monday.getUTCDate()),
      thursday: new Date(thursday.getUTCFullYear(), thursday.getUTCMonth(), thursday.getUTCDate()),
    };
  }

  function countMondayOfMonth(date) {
    let mondayCount = 0;
    for (let day = 1; day <= date.getDate(); day += 1) {
      if (new Date(date.getFullYear(), date.getMonth(), day).getDay() === 1) {
        mondayCount += 1;
      }
    }
    return mondayCount;
  }

  function formatWeekLabel(weekKey) {
    const dates = isoWeekKeyToLocalDates(weekKey);
    if (!dates) return String(weekKey).replace('-W', ' W');

    const monday = dates.monday;
    const month = monday.toLocaleDateString('da-DK', { month: 'short' })
      .replace('.', '')
      .replace(/^\w/u, (char) => char.toUpperCase());
    const weekInMonth = countMondayOfMonth(monday);
    return `${month} W${weekInMonth}`;
  }
  function formatMonthLabel(month) {
    const [year, monthNumber] = String(month).split('-');
    return new Date(Number(year), Number(monthNumber) - 1, 1).toLocaleDateString('da-DK', { month: 'short', year: '2-digit' });
  }
  function truncateLabel(label, max = 18) {
    const text = String(label);
    return text.length > max ? `${text.slice(0, max - 1)}…` : text;
  }
  function getThemeColors() {
    return {
      text: '#1a1208',
      muted: '#6b5348',
      grid: 'rgba(26, 18, 8, 0.1)',
      border: '#e8e0d8',
      tooltipBg: '#ffffff',
      tooltipBorder: '#e8e0d8',
      tooltipText: '#1a1208',
    };
  }
  function seriesFromRows(rows, labelKey, valueKey, labelFormatter) {
    return {
      labels: rows.map((row) => labelFormatter(row[labelKey])),
      values: rows.map((row) => Number(row[valueKey]) || 0),
    };
  }

  function formatAxisCurrency(value) {
    const amount = Number(value) || 0;
    if (amount >= 1000000) return `${(amount / 1000000).toFixed(1)}M`;
    if (amount >= 1000) return `${Math.round(amount / 1000)}K`;
    return amount;
  }

  function mergeMonthlySpendRevenue(data) {
    const spendByMonth = new Map((data.monthlyAdSpend || []).map((row) => [row.month, Number(row.spend) || 0]));
    const revenueByMonth = new Map((data.monthlyRevenue || []).map((row) => [row.month, Number(row.revenue) || 0]));
    const months = [...new Set([...spendByMonth.keys(), ...revenueByMonth.keys()])].sort();

    return {
      dualAxis: true,
      labels: months.map((month) => formatMonthLabel(month)),
      spendValues: months.map((month) => spendByMonth.get(month) || 0),
      revenueValues: months.map((month) => revenueByMonth.get(month) || 0),
    };
  }

  function buildDualAxisConfig(definition, extracted, colors) {
    const hasData = extracted.spendValues.some((value) => value > 0)
      || extracted.revenueValues.some((value) => value > 0);
    if (!extracted.labels.length || !hasData) return null;

    return {
      type: 'bar',
      data: {
        labels: extracted.labels,
        datasets: [
          {
            type: 'bar',
            label: 'Ad Spend',
            data: extracted.spendValues,
            backgroundColor: '#ff6a00cc',
            borderColor: '#ff6a00',
            borderWidth: 2,
            borderRadius: 6,
            maxBarThickness: 42,
            yAxisID: 'y',
            order: 2,
          },
          {
            type: 'line',
            label: 'Won Revenue',
            data: extracted.revenueValues,
            backgroundColor: '#138b5333',
            borderColor: '#138b53',
            borderWidth: 2.5,
            fill: true,
            tension: 0.35,
            pointRadius: 4,
            pointHoverRadius: 6,
            yAxisID: 'y1',
            order: 1,
          },
        ],
      },
      options: {
        responsive: true,
        maintainAspectRatio: false,
        interaction: { mode: 'index', intersect: false },
        plugins: {
          legend: {
            display: true,
            position: 'bottom',
            align: 'center',
            labels: {
              color: colors.text,
              boxWidth: 12,
              boxHeight: 12,
              padding: 14,
            },
          },
          tooltip: {
            backgroundColor: colors.tooltipBg,
            borderColor: colors.tooltipBorder,
            borderWidth: 1,
            titleColor: colors.tooltipText,
            bodyColor: colors.muted,
            padding: 12,
            callbacks: {
              label(context) {
                const value = context.parsed.y ?? 0;
                return `${context.dataset.label}: Dkr ${Math.round(value).toLocaleString('da-DK')}`;
              },
            },
          },
        },
        scales: {
          x: {
            ticks: { color: colors.muted, maxRotation: 45, minRotation: 0 },
            grid: { color: colors.grid },
            border: { color: colors.border },
          },
          y: {
            type: 'linear',
            position: 'left',
            title: {
              display: true,
              text: 'Ad Spend (Dkr)',
              color: '#ff6a00',
              font: { size: 11, weight: '600' },
            },
            ticks: {
              color: '#ff6a00',
              callback: formatAxisCurrency,
            },
            grid: { color: colors.grid },
            border: { color: colors.border },
            beginAtZero: true,
          },
          y1: {
            type: 'linear',
            position: 'right',
            title: {
              display: true,
              text: 'Won Revenue (Dkr)',
              color: '#138b53',
              font: { size: 11, weight: '600' },
            },
            ticks: {
              color: '#138b53',
              callback: formatAxisCurrency,
            },
            grid: { drawOnChartArea: false },
            border: { color: colors.border },
            beginAtZero: true,
          },
        },
      },
    };
  }

  const CHART_DEFINITIONS = {
    weeklyRevenue: { title: 'Won Revenue (Weekly)', defaultType: 'area', format: 'currency', extract(data) { return seriesFromRows(data.weeklyRevenue || [], 'week', 'revenue', formatWeekLabel); } },
    monthlyRevenue: { title: 'Won Revenue (Monthly)', defaultType: 'area', format: 'currency', extract(data) { return seriesFromRows(data.monthlyRevenue || [], 'month', 'revenue', formatMonthLabel); } },
    weeklyLeads: { title: 'New Leads (Weekly)', defaultType: 'area', format: 'number', extract(data) { return seriesFromRows(data.weeklyLeads || [], 'week', 'count', formatWeekLabel); } },
    monthlyLeads: { title: 'New Leads (Monthly)', defaultType: 'area', format: 'number', extract(data) { return seriesFromRows(data.monthlyLeads || [], 'month', 'count', formatMonthLabel); } },
    conversionTrend: { title: 'Conversion Rate Trend', defaultType: 'line', format: 'percent', extract(data) { return seriesFromRows(data.monthlyConversion || [], 'month', 'rate', formatMonthLabel); } },
    statusBreakdown: { title: 'Opportunity Status', defaultType: 'doughnut', format: 'number', extract(data) {
      const breakdown = data.chartStatusBreakdown || data.statusBreakdown || {};
      const keys = ['open', 'won', 'lost', 'abandoned'];
      return { labels: ['Open', 'Won', 'Lost', 'Abandoned'], values: keys.map((key) => Number(breakdown[key]) || 0), colors: keys.map((key) => STATUS_COLORS[key]) };
    } },
    marketingSpendComparison: { title: 'Facebook Ad Spend', defaultType: 'area', format: 'currency', extract(data) {
      return seriesFromRows((data.monthlyAdSpend || []).slice(-8), 'month', 'spend', formatMonthLabel);
    } },
    monthlyCostPerLead: { title: 'Cost per Lead (Monthly)', defaultType: 'area', format: 'currency', extract(data) {
      return seriesFromRows(data.monthlyCostPerLead || [], 'month', 'cpl', formatMonthLabel);
    } },
  };

  function formatTooltipValue(value, format, valueFormats, index) {
    const amount = Number(value) || 0;
    const rowFormat = Array.isArray(valueFormats) ? valueFormats[index] : format;
    if (rowFormat === 'ratio') return `${amount.toFixed(2)}x`;
    if (rowFormat === 'currency' || format === 'currency') return `Dkr ${Math.round(amount).toLocaleString('da-DK')}`;
    if (rowFormat === 'percent' || format === 'percent') return `${amount.toFixed(1)}%`;
    return Math.round(amount).toLocaleString('da-DK');
  }

  function buildChartConfig(chartId, data, chartType) {
    const definition = CHART_DEFINITIONS[chartId];
    if (!definition) return null;
    const extracted = definition.extract(data);
    const colors = getThemeColors();

    if (extracted.dualAxis || chartType === 'dualAxis') {
      return buildDualAxisConfig(definition, extracted, colors);
    }

    if (!extracted.labels?.length || extracted.values.every((value) => value === 0)) return null;
    const isCircular = ['pie', 'doughnut', 'polarArea'].includes(chartType);
    const datasetColors = extracted.colors || extracted.labels.map((_, index) => PALETTE[index % PALETTE.length]);
    const resolvedType = chartType === 'area' ? 'line' : chartType === 'horizontalBar' ? 'bar' : chartType;

    const areaFill = `${PALETTE[0]}55`;
    const isDoughnut = chartType === 'doughnut';

    const dataset = {
      label: definition.title,
      data: extracted.values,
      backgroundColor: isCircular
        ? (isDoughnut ? datasetColors : datasetColors.map((color) => `${color}cc`))
        : extracted.colors
          ? extracted.colors.map((color) => `${color}cc`)
          : chartType === 'area' ? areaFill : `${PALETTE[0]}cc`,
      borderColor: isCircular ? datasetColors : extracted.colors || PALETTE[0],
      borderWidth: isCircular ? (isDoughnut ? 0 : 1) : 2,
      fill: chartType === 'area',
      tension: 0.35,
      borderRadius: isCircular ? 0 : 6,
      maxBarThickness: 42,
      ...(isDoughnut ? { cutout: '62%', borderAlign: 'inner' } : {}),
    };

    return {
      type: resolvedType,
      data: { labels: extracted.labels, datasets: [dataset] },
      options: {
        responsive: true,
        maintainAspectRatio: isDoughnut ? false : isCircular,
        indexAxis: chartType === 'horizontalBar' ? 'y' : 'x',
        plugins: {
          legend: {
            display: isCircular,
            position: 'bottom',
            align: 'center',
            labels: {
              color: colors.text,
              boxWidth: 12,
              boxHeight: 12,
              padding: 14,
            },
          },
          tooltip: {
            backgroundColor: colors.tooltipBg,
            borderColor: colors.tooltipBorder,
            borderWidth: 1,
            titleColor: colors.tooltipText,
            bodyColor: colors.muted,
            padding: 12,
            callbacks: {
              label(context) {
                const parsed = context.parsed;
                const value = typeof parsed === 'object' ? (parsed.y ?? parsed.x ?? 0) : (parsed ?? 0);
                return `${context.label}: ${formatTooltipValue(value, definition.format, extracted.valueFormats, context.dataIndex)}`;
              },
            },
          },
        },
        ...(isDoughnut ? {
          layout: { padding: 8 },
          devicePixelRatio: typeof window !== 'undefined' ? Math.min(window.devicePixelRatio || 1, 2) : 1,
          elements: { arc: { borderAlign: 'inner' } },
        } : {}),
        scales: isCircular ? {} : {
          x: {
            ticks: { color: colors.muted, maxRotation: 45, minRotation: 0 },
            grid: { color: colors.grid },
            border: { color: colors.border },
          },
          y: {
            ticks: {
              color: colors.muted,
              callback(value, index) {
                if (definition.format === 'mixed' && extracted.valueFormats?.[index] === 'ratio') {
                  return `${Number(value).toFixed(2)}x`;
                }
                if (definition.format === 'currency' || extracted.valueFormats?.[index] === 'currency') {
                  return value >= 1000000 ? `${(value / 1000000).toFixed(1)}M` : value >= 1000 ? `${Math.round(value / 1000)}K` : value;
                }
                if (definition.format === 'percent') return `${value}%`;
                return value;
              },
            },
            grid: { color: colors.grid },
            border: { color: colors.border },
            beginAtZero: true,
          },
        },
      },
    };
  }

  global.DashboardCharts = { CHART_DEFINITIONS, buildChartConfig, formatTooltipValue };
})(window);

const STORAGE_KEY = `cenhub_display_${CLIENT_SLUG}`;
const LEGACY_STORAGE_KEY = 'suntech-dashboard-display';
const PIPELINE_KEY = 'suntech-dashboard-pipelines';

const DISPLAY_OPTIONS = {
  kpis: {
    totalRevenue: 'Total Revenue',
    adSpend: 'Ad Spend',
    roas: 'ROAS',
    roasDk: 'ROAS (DK)',
    poas: 'POAS',
    poasDk: 'POAS (DK)',
    costPerLead: 'Cost per Lead',
    costPerWonClient: 'Cost per Won Client',
    clientsWon: 'Clients Won',
    totalLeads: 'Total Leads',
    totalLeadsValue: 'Total Leads Value',
    averageLeadValue: 'Average Lead Value',
    conversionRate: 'Conversion Rate',
    totalBundlinje: 'Total Bundlinje',
    openLeads: 'Open Leads',
    openPipelineValue: 'Open Pipeline Value',
    averageWonDealSize: 'Avg Won Deal Size',
  },
  sections: {
    statusBreakdown: 'Opportunity Status (Cards)',
    sourceReport: 'Lead Source Report',
    assigneeReport: 'Leads Closed by Assignee',
    pipelineBreakdown: 'Pipeline Breakdown',
  },
  charts: {
    weeklyRevenue: 'Won Revenue (Weekly)',
    monthlyRevenue: 'Won Revenue (Monthly)',
    marketingSpendComparison: 'Facebook Ad Spend',
    monthlyCostPerLead: 'Cost per Lead (Monthly)',
    weeklyLeads: 'New Leads (Weekly)',
    monthlyLeads: 'New Leads (Monthly)',
    conversionTrend: 'Conversion Rate Trend',
    statusBreakdown: 'Opportunity Status',
  },
  statusItems: {
    open: 'Open',
    won: 'Won',
    lost: 'Lost',
    abandoned: 'Abandoned',
  },
  columns: {
    sourceReport: {
      totalLeads: 'Total leads',
      totalValue: 'Total values',
      open: 'Open',
      won: 'Won',
      lost: 'Lost',
      abandoned: 'Abandoned',
      winPct: 'Win %',
    },
    assigneeReport: {
      won: 'Won',
      totalLeads: 'Total leads',
      wonValue: 'Won revenue',
      totalValue: 'Total value',
    },
    pipelineBreakdown: {
      count: 'Leads',
      won: 'Won',
      monetary: 'Value',
      profit: 'Bundlinje',
      wonValue: 'Won revenue',
    },
  },
};

const state = {
  pipelineIds: usesClientPipelineDefaults() ? [] : loadPipelineSelection(),
  status: 'all',
  source: 'all',
  assignedTo: 'all',
  dateField: 'createdAt',
  dateFrom: '',
  dateTo: '',
  adSpend: '',
  preset: 'all',
};

let cachedData = null;
let cachedFacebookMetrics = null;
let cachedMonthlyAdSpend = null;
let availablePipelines = [];
let display = loadDisplayPrefs();
let pipelineDefaultsApplied = false;
let chartInstances = {};
let chartFieldsCache = null;
let chartFieldsCacheKey = null;
let lastFetchedAt = 0;
const DATA_REFRESH_MS = 2 * 60 * 1000;
const DATA_FRESH_MS = DATA_REFRESH_MS;

const CHART_FIELD_KEYS = [
  'weeklyRevenue',
  'monthlyRevenue',
  'weeklyLeads',
  'monthlyLeads',
  'monthlyLeadsValue',
  'monthlyConversion',
  'chartStatusBreakdown',
];

function getChartCacheKey() {
  return [
    [...state.pipelineIds].sort().join(','),
    state.status,
    state.source,
    state.assignedTo,
    state.dateField,
    state.dateFrom || '',
    state.dateTo || '',
  ].join('|');
}

function cacheChartFields(data) {
  chartFieldsCache = {};
  CHART_FIELD_KEYS.forEach((key) => {
    if (data[key] !== undefined) chartFieldsCache[key] = data[key];
  });
  chartFieldsCacheKey = getChartCacheKey();
}

function applyChartFieldsCache(data) {
  const hasDateFilter = Boolean(state.dateFrom || state.dateTo);
  if (!hasDateFilter) {
    cacheChartFields(data);
    return data;
  }
  if (chartFieldsCache && chartFieldsCacheKey === getChartCacheKey()) {
    const merged = { ...data };
    CHART_FIELD_KEYS.forEach((key) => {
      if (chartFieldsCache[key] !== undefined) merged[key] = chartFieldsCache[key];
    });
    return merged;
  }
  cacheChartFields(data);
  return data;
}

function getDefaultChartPrefs() {
  const prefs = {};
  const chartKeys = window.DashboardCharts
    ? Object.keys(DashboardCharts.CHART_DEFINITIONS)
    : Object.keys(DISPLAY_OPTIONS.charts);
  chartKeys.forEach((key) => { prefs[key] = true; });
  return prefs;
}

function destroyCharts() {
  Object.values(chartInstances).forEach((chart) => chart.destroy());
  chartInstances = {};
}

function mountCharts(data) {
  if (typeof Chart === 'undefined' || !window.DashboardCharts) return;

  destroyCharts();

  Object.keys(DashboardCharts.CHART_DEFINITIONS).forEach((chartId) => {
    if (!isVisible('charts', chartId)) return;

    const definition = DashboardCharts.CHART_DEFINITIONS[chartId];
    const canvas = document.getElementById(`chart-${chartId}`);
    if (!canvas) return;

    const wrapper = canvas.closest('.chart-card');
    const emptyState = wrapper?.querySelector('.chart-empty');
    const chartType = definition?.defaultType || 'bar';
    const config = DashboardCharts.buildChartConfig(chartId, data, chartType);

    if (!config) {
      canvas.style.display = 'none';
      if (emptyState) emptyState.style.display = 'block';
      return;
    }

    canvas.style.display = 'block';
    if (emptyState) emptyState.style.display = 'none';
    chartInstances[chartId] = new Chart(canvas, config);
  });
}

function usesClientPipelineDefaults() {
  return IS_CLIENT_VIEW || IS_ADMIN;
}

function getPipelineStorageKey() {
  return `cenhub_pipelines_${facebookClientId || CLIENT_SLUG}`;
}

function loadPipelineSelection() {
  try {
    const saved = JSON.parse(localStorage.getItem(getPipelineStorageKey()) || '[]');
    return Array.isArray(saved) ? saved : [];
  } catch {
    return [];
  }
}

function getAllPipelineIds(pipelines) {
  return pipelines.map((pipeline) => pipeline.id);
}

function getDefaultPipelineIds(pipelines, accountDefaults = []) {
  const allIds = getAllPipelineIds(pipelines);
  const fromAccount = (accountDefaults || []).filter((id) => allIds.includes(id));
  if (fromAccount.length) return fromAccount;
  return allIds.length ? allIds : [];
}

function ensurePipelineDefaults(pipelines, accountDefaults = []) {
  if (!pipelines.length) return;

  if (usesClientPipelineDefaults()) {
    state.pipelineIds = getDefaultPipelineIds(pipelines, accountDefaults);
    pipelineDefaultsApplied = true;
    return;
  }

  const allIds = getAllPipelineIds(pipelines);
  let saved = loadPipelineSelection();
  if (!saved.length) {
    try {
      saved = JSON.parse(localStorage.getItem(PIPELINE_KEY) || '[]');
    } catch {
      saved = [];
    }
  }

  if (!saved.length || !pipelineDefaultsApplied) {
    if (!saved.length) {
      state.pipelineIds = getDefaultPipelineIds(pipelines, accountDefaults);
    } else {
      state.pipelineIds = saved.filter((id) => allIds.includes(id));
      if (!state.pipelineIds.length) {
        state.pipelineIds = getDefaultPipelineIds(pipelines, accountDefaults);
      }
    }
    pipelineDefaultsApplied = true;
    savePipelineSelection();
  } else if (!state.pipelineIds.length) {
    state.pipelineIds = getDefaultPipelineIds(pipelines, accountDefaults);
    savePipelineSelection();
  }
}

function ensurePipelineSelectionBeforeFetch() {
  if (state.pipelineIds.length) return true;
  if (!availablePipelines.length) return false;
  state.pipelineIds = getDefaultPipelineIds(
    availablePipelines,
    cachedData?.account?.defaultPipelineIds,
  );
  if (state.pipelineIds.length && !usesClientPipelineDefaults()) savePipelineSelection();
  return state.pipelineIds.length > 0;
}

function savePipelineSelection() {
  localStorage.setItem(getPipelineStorageKey(), JSON.stringify(state.pipelineIds));
}

function isPipelineSelected(id) {
  return state.pipelineIds.includes(id);
}

function isAllPipelinesSelected(pipelines) {
  const allIds = getAllPipelineIds(pipelines);
  return allIds.length > 0 && allIds.every((id) => state.pipelineIds.includes(id));
}

function selectAllPipelines(pipelines) {
  state.pipelineIds = getAllPipelineIds(pipelines);
  savePipelineSelection();
}

function clearPipelineSelection() {
  state.pipelineIds = [];
  savePipelineSelection();
}

function setPipelineSelection(ids) {
  state.pipelineIds = [...new Set(ids)];
  savePipelineSelection();
}

function togglePipelineSelection(pipelineId) {
  if (isPipelineSelected(pipelineId)) {
    state.pipelineIds = state.pipelineIds.filter((id) => id !== pipelineId);
  } else {
    state.pipelineIds = [...state.pipelineIds, pipelineId];
  }
  savePipelineSelection();
}

function formatSelectedPipelines(pipelines) {
  if (!state.pipelineIds.length) return 'None selected';
  if (isAllPipelinesSelected(pipelines)) return 'All pipelines';

  return state.pipelineIds
    .map((id) => pipelines.find((pipeline) => pipeline.id === id)?.name || id)
    .join(', ');
}

function renderPipelineChips(pipelines) {
  if (!state.pipelineIds.length) {
    return '<div class="pipeline-warning">Select at least one pipeline, then click Apply data filters.</div>';
  }

  const selectedNames = state.pipelineIds
    .map((id) => pipelines.find((pipeline) => pipeline.id === id))
    .filter(Boolean);

  return `
    <div class="pipeline-chips">
      ${selectedNames.map((pipeline) => `
        <span class="pipeline-chip">${esc(pipeline.name)}</span>
      `).join('')}
    </div>
  `;
}

function defaultDisplayPrefs() {
  const prefs = {
    kpis: {},
    sections: {},
    charts: getDefaultChartPrefs(),
    statusItems: {},
    columns: {},
  };
  Object.keys(DISPLAY_OPTIONS.kpis).forEach((key) => { prefs.kpis[key] = true; });
  Object.keys(DISPLAY_OPTIONS.sections).forEach((key) => { prefs.sections[key] = true; });
  Object.keys(DISPLAY_OPTIONS.charts).forEach((key) => { prefs.charts[key] = true; });
  Object.keys(DISPLAY_OPTIONS.statusItems).forEach((key) => { prefs.statusItems[key] = true; });
  Object.entries(DISPLAY_OPTIONS.columns).forEach(([table, columns]) => {
    prefs.columns[table] = {};
    Object.keys(columns).forEach((key) => { prefs.columns[table][key] = true; });
  });
  return prefs;
}

function loadDisplayPrefs() {
  if (IS_CLIENT_VIEW && !IS_PREVIEW) {
    return defaultDisplayPrefs();
  }
  try {
    const saved = JSON.parse(
      localStorage.getItem(STORAGE_KEY)
      || localStorage.getItem(LEGACY_STORAGE_KEY)
      || 'null',
    );
    if (!saved) return defaultDisplayPrefs();
    const defaults = defaultDisplayPrefs();
    return {
      kpis: { ...defaults.kpis, ...saved.kpis },
      sections: { ...defaults.sections, ...saved.sections },
      charts: { ...defaults.charts, ...saved.charts },
      statusItems: { ...defaults.statusItems, ...saved.statusItems },
      columns: {
        sourceReport: { ...defaults.columns.sourceReport, ...(saved.columns?.sourceReport || {}) },
        assigneeReport: { ...defaults.columns.assigneeReport, ...(saved.columns?.assigneeReport || {}) },
        pipelineBreakdown: { ...defaults.columns.pipelineBreakdown, ...(saved.columns?.pipelineBreakdown || {}) },
      },
    };
  } catch {
    return defaultDisplayPrefs();
  }
}

function ensureChartsVisible() {
  const chartKeys = Object.keys(DISPLAY_OPTIONS.charts);
  const anyVisible = chartKeys.some((key) => display.charts[key] !== false);
  if (!anyVisible) {
    chartKeys.forEach((key) => { display.charts[key] = true; });
    saveDisplayPrefs();
  }
}

function saveDisplayPrefs() {
  localStorage.setItem(STORAGE_KEY, JSON.stringify(display));
}

function isVisible(group, key, table) {
  if (group === 'columns') return display.columns[table]?.[key] !== false;
  return display[group]?.[key] !== false;
}

function toggleDisplay(group, key, table) {
  if (group === 'columns') {
    display.columns[table][key] = !display.columns[table][key];
  } else {
    display[group][key] = !display[group][key];
  }
  saveDisplayPrefs();
  if (cachedData) updateDashboardContent(cachedData);
}

function setAllDisplay(group, value, table) {
  if (group === 'columns') {
    Object.keys(DISPLAY_OPTIONS.columns[table]).forEach((key) => {
      display.columns[table][key] = value;
    });
  } else {
    Object.keys(DISPLAY_OPTIONS[group]).forEach((key) => {
      display[group][key] = value;
    });
  }
  saveDisplayPrefs();
  if (cachedData) updateDashboardContent(cachedData);
}

const fmt = (value) => new Intl.NumberFormat('da-DK', {
  minimumFractionDigits: 0,
  maximumFractionDigits: 0,
}).format(Math.round(Number(value) || 0));

const fmtCompact = (value) => {
  const amount = Number(value) || 0;
  if (amount >= 1_000_000) return `${(amount / 1_000_000).toFixed(2)}M`;
  if (amount >= 1_000) return `${(amount / 1_000).toFixed(2)}K`;
  return fmt(amount);
};

const fmtPct = (value) => `${(Number(value) || 0).toFixed(2)}%`;
const fmtRoas = (value) => {
  const amount = Number(value) || 0;
  return amount > 0 ? `${amount.toFixed(2)}x` : '—';
};

function formatActiveDateFilter(filters) {
  if (!filters.dateFrom && !filters.dateTo) return 'Till date';
  const timeZone = getDashboardTimeZone();
  if (window.MarketingMetrics?.formatShortDateLabel) {
    const from = window.MarketingMetrics.formatShortDateLabel(filters.dateFrom, timeZone);
    const to = window.MarketingMetrics.formatShortDateLabel(filters.dateTo, timeZone);
    if (from && to) return `${from} – ${to}`;
  }
  return `${filters.dateFrom || 'start'} to ${filters.dateTo || 'now'}`;
}

function showDateRangeError(message) {
  document.querySelectorAll('#date-range-error').forEach((el) => {
    el.textContent = message;
    el.hidden = !message;
  });
}

function clearDateRangeError() {
  showDateRangeError('');
}

function needsFreshData() {
  return !lastFetchedAt || Date.now() - lastFetchedAt > DATA_FRESH_MS;
}

function buildQuery(pipelines, options = {}) {
  const params = new URLSearchParams();
  const allIds = getAllPipelineIds(pipelines || []);
  const selected = state.pipelineIds.filter((id) => allIds.includes(id));

  if (!selected.length) {
    throw new Error('Select at least one pipeline.');
  }

  params.set('pipelineIds', selected.join(','));

  if (state.dateField) params.set('dateField', state.dateField);
  if (state.dateFrom) params.set('dateFrom', state.dateFrom);
  if (state.dateTo) params.set('dateTo', state.dateTo);

  ['status', 'source', 'assignedTo', 'adSpend'].forEach((key) => {
    if (state[key] && state[key] !== 'all') params.set(key, state[key]);
  });
  appendTenantParams(params);
  if (options.forceFresh) params.set('fresh', '1');
  return params.toString();
}

function formatDateInput(date) {
  const year = date.getFullYear();
  const month = String(date.getMonth() + 1).padStart(2, '0');
  const day = String(date.getDate()).padStart(2, '0');
  return `${year}-${month}-${day}`;
}

function getDashboardTimeZone() {
  return cachedData?.account?.timezone || 'Europe/Copenhagen';
}

function getCalendarPartsInTimeZone(timeZone, date = new Date()) {
  const parts = new Intl.DateTimeFormat('en-CA', {
    timeZone,
    year: 'numeric',
    month: '2-digit',
    day: '2-digit',
  }).formatToParts(date);
  return {
    year: Number(parts.find((part) => part.type === 'year')?.value),
    month: Number(parts.find((part) => part.type === 'month')?.value),
    day: Number(parts.find((part) => part.type === 'day')?.value),
  };
}

function formatMonthDateRange(year, month) {
  const start = `${year}-${String(month).padStart(2, '0')}-01`;
  const daysInMonth = new Date(year, month, 0).getDate();
  const end = `${year}-${String(month).padStart(2, '0')}-${String(daysInMonth).padStart(2, '0')}`;
  return { start, end };
}

const datePickerState = {
  inputId: null,
  anchorEl: null,
  viewYear: null,
  viewMonth: null,
};

let datePickerListenersBound = false;

function isoFromParts(year, month, day) {
  const safeDay = Number(day);
  if (!year || !month || !Number.isFinite(safeDay)) return '';
  return `${year}-${String(month).padStart(2, '0')}-${String(safeDay).padStart(2, '0')}`;
}

function formatPickerDisplayLabel(iso, placeholder) {
  if (!iso || !/^\d{4}-\d{2}-\d{2}$/.test(iso)) return placeholder;
  const timeZone = getDashboardTimeZone();
  if (window.MarketingMetrics?.formatShortDateLabel) {
    return window.MarketingMetrics.formatShortDateLabel(iso, timeZone) || iso;
  }
  return iso;
}

function ensureDatePickerPopover() {
  if (document.getElementById('date-picker-popover')) return;

  const backdrop = document.createElement('div');
  backdrop.id = 'date-picker-backdrop';
  backdrop.className = 'date-picker-backdrop';
  backdrop.hidden = true;
  backdrop.addEventListener('click', closeDatePicker);
  document.body.appendChild(backdrop);

  const popover = document.createElement('div');
  popover.id = 'date-picker-popover';
  popover.className = 'date-picker-popover';
  popover.hidden = true;
  popover.setAttribute('role', 'dialog');
  popover.setAttribute('aria-modal', 'true');
  document.body.appendChild(popover);
}

function syncDatePickerDisplays() {
  [
    { id: 'dateFrom', key: 'dateFrom', placeholder: 'Pick start date' },
    { id: 'dateTo', key: 'dateTo', placeholder: 'Pick end date' },
  ].forEach(({ id, key, placeholder }) => {
    const input = document.getElementById(id);
    const display = document.getElementById(`${id}-display`);
    const trigger = document.getElementById(`${id}-trigger`);
    const value = state[key] ?? '';
    if (input) input.value = value;
    if (display) display.textContent = formatPickerDisplayLabel(value, placeholder);
    trigger?.classList.toggle('is-empty', !value);
    trigger?.classList.toggle('has-value', Boolean(value));
  });
}

function getStateDateValue(key) {
  return state[key] ?? '';
}

function getDatePickerViewMonth(inputId) {
  const value = getStateDateValue(inputId);
  if (/^\d{4}-\d{2}-\d{2}$/.test(value)) {
    const [year, month] = value.split('-').map(Number);
    return { year, month };
  }
  return getCalendarPartsInTimeZone(getDashboardTimeZone());
}

function getTodayIso() {
  const parts = getCalendarPartsInTimeZone(getDashboardTimeZone());
  return isoFromParts(parts.year, parts.month, parts.day);
}

function isStartDateDisabled(iso) {
  return iso >= getTodayIso();
}

function isFutureDateDisabled(iso) {
  return iso > getTodayIso();
}

function isFutureMonthView(year, month) {
  const parts = getCalendarPartsInTimeZone(getDashboardTimeZone());
  return year > parts.year || (year === parts.year && month > parts.month);
}

function isDatePickerDayDisabled(iso, inputId) {
  if (inputId === 'dateFrom' && isStartDateDisabled(iso)) return true;
  return isFutureDateDisabled(iso);
}

function renderDatePickerDayCell(iso, dayNum, isOutside, todayIso, selectedValue, fromVal, toVal, inputId) {
  const classes = ['date-picker-day'];
  if (isOutside) classes.push('is-outside');
  if (iso === todayIso) classes.push('is-today');
  if (iso === selectedValue) classes.push('is-selected');
  if (fromVal && toVal) {
    const start = fromVal <= toVal ? fromVal : toVal;
    const end = fromVal <= toVal ? toVal : fromVal;
    if (iso >= start && iso <= end) classes.push('is-in-range');
  }
  if (iso === fromVal) classes.push('is-range-start');
  if (iso === toVal) classes.push('is-range-end');
  if (isDatePickerDayDisabled(iso, inputId)) {
    classes.push('is-disabled');
    return `<button type="button" class="${classes.join(' ')}" disabled aria-disabled="true">${dayNum}</button>`;
  }
  return `<button type="button" class="${classes.join(' ')}" onclick="selectDatePickerDay('${iso}')">${dayNum}</button>`;
}

function renderDatePickerPopover() {
  const popover = document.getElementById('date-picker-popover');
  if (!popover || !datePickerState.inputId) return;

  const { viewYear, viewMonth, inputId } = datePickerState;
  const monthLabel = new Intl.DateTimeFormat('en-GB', {
    month: 'long',
    year: 'numeric',
  }).format(new Date(viewYear, viewMonth - 1, 1));
  const weekdays = ['Mo', 'Tu', 'We', 'Th', 'Fr', 'Sa', 'Su'];
  const firstDay = new Date(viewYear, viewMonth - 1, 1);
  const mondayOffset = (firstDay.getDay() + 6) % 7;
  const daysInMonth = new Date(viewYear, viewMonth, 0).getDate();
  const daysInPrevMonth = new Date(viewYear, viewMonth - 1, 0).getDate();
  const todayParts = getCalendarPartsInTimeZone(getDashboardTimeZone());
  const todayIso = isoFromParts(todayParts.year, todayParts.month, todayParts.day);
  const selectedValue = getStateDateValue(inputId);
  const fromVal = getStateDateValue('dateFrom');
  const toVal = getStateDateValue('dateTo');

  let cells = '';
  for (let index = mondayOffset - 1; index >= 0; index -= 1) {
    const day = daysInPrevMonth - index;
    const month = viewMonth === 1 ? 12 : viewMonth - 1;
    const year = viewMonth === 1 ? viewYear - 1 : viewYear;
    const iso = isoFromParts(year, month, day);
    cells += renderDatePickerDayCell(iso, day, true, todayIso, selectedValue, fromVal, toVal, inputId);
  }

  for (let day = 1; day <= daysInMonth; day += 1) {
    const iso = isoFromParts(viewYear, viewMonth, day);
    cells += renderDatePickerDayCell(iso, day, false, todayIso, selectedValue, fromVal, toVal, inputId);
  }

  const trailing = (7 - ((mondayOffset + daysInMonth) % 7)) % 7;
  for (let day = 1; day <= trailing; day += 1) {
    const month = viewMonth === 12 ? 1 : viewMonth + 1;
    const year = viewMonth === 12 ? viewYear + 1 : viewYear;
    const iso = isoFromParts(year, month, day);
    cells += renderDatePickerDayCell(iso, day, true, todayIso, selectedValue, fromVal, toVal, inputId);
  }

  const footerHint = inputId === 'dateFrom'
    ? '<span class="date-picker-hint">Start date must be before today</span>'
    : '';
  const todayButton = inputId === 'dateTo'
    ? '<button type="button" class="date-picker-footer-btn primary" onclick="setDatePickerToday()">Today</button>'
    : '';

  const nextViewMonth = viewMonth === 12 ? 1 : viewMonth + 1;
  const nextViewYear = viewMonth === 12 ? viewYear + 1 : viewYear;
  const showNextMonth = !isFutureMonthView(nextViewYear, nextViewMonth);

  popover.innerHTML = `
    <div class="date-picker-panel">
      <div class="date-picker-header">
        <div class="date-picker-title">${esc(monthLabel)}</div>
        <div class="date-picker-nav">
          <button type="button" class="date-picker-nav-btn" aria-label="Previous month" onclick="shiftDatePickerMonth(-1)">${ICON_CHEVRON_LEFT}</button>
          <button type="button" class="date-picker-nav-btn" aria-label="Next month" onclick="shiftDatePickerMonth(1)" ${showNextMonth ? '' : 'disabled'}>${ICON_CHEVRON_RIGHT}</button>
        </div>
      </div>
      <div class="date-picker-weekdays">
        ${weekdays.map((day) => `<div class="date-picker-weekday">${day}</div>`).join('')}
      </div>
      <div class="date-picker-grid">${cells}</div>
      <div class="date-picker-footer">
        ${footerHint}
        <button type="button" class="date-picker-footer-btn" onclick="clearDatePickerField()">Clear</button>
        ${todayButton}
      </div>
    </div>
  `;
}

function positionDatePickerPopover() {
  const popover = document.getElementById('date-picker-popover');
  const anchor = datePickerState.anchorEl;
  if (!popover || !anchor) return;

  popover.hidden = false;
  popover.style.visibility = 'hidden';
  popover.style.left = '0';
  popover.style.top = '0';
  popover.style.transform = '';

  const rect = anchor.getBoundingClientRect();
  const popRect = popover.getBoundingClientRect();
  const margin = 8;
  let top = rect.bottom + margin;
  let left = rect.left;

  if (window.innerWidth <= 640) {
    left = Math.max(16, (window.innerWidth - popRect.width) / 2);
    top = Math.max(16, (window.innerHeight - popRect.height) / 2);
    popover.style.transform = 'none';
  } else {
    if (left + popRect.width > window.innerWidth - 16) {
      left = window.innerWidth - popRect.width - 16;
    }
    if (left < 16) left = 16;
    if (top + popRect.height > window.innerHeight - 16) {
      top = Math.max(16, rect.top - popRect.height - margin);
    }
  }

  popover.style.top = `${top}px`;
  popover.style.left = `${left}px`;
  popover.style.visibility = '';
}

function openDatePicker(inputId, anchorEl) {
  ensureDatePickerPopover();
  const popover = document.getElementById('date-picker-popover');
  const backdrop = document.getElementById('date-picker-backdrop');
  if (!popover || !backdrop || !anchorEl) return;

  if (datePickerState.inputId === inputId && !popover.hidden) {
    closeDatePicker();
    return;
  }

  closeDatePicker();
  datePickerState.inputId = inputId;
  datePickerState.anchorEl = anchorEl;
  const view = getDatePickerViewMonth(inputId);
  datePickerState.viewYear = view.year;
  datePickerState.viewMonth = view.month;
  renderDatePickerPopover();
  backdrop.hidden = false;
  anchorEl.classList.add('is-active');
  positionDatePickerPopover();
}

function closeDatePicker() {
  const popover = document.getElementById('date-picker-popover');
  const backdrop = document.getElementById('date-picker-backdrop');
  if (popover) popover.hidden = true;
  if (backdrop) backdrop.hidden = true;
  datePickerState.anchorEl?.classList.remove('is-active');
  datePickerState.inputId = null;
  datePickerState.anchorEl = null;
}

function shiftDatePickerMonth(delta) {
  let { viewYear, viewMonth } = datePickerState;
  viewMonth += delta;
  if (viewMonth < 1) {
    viewMonth = 12;
    viewYear -= 1;
  } else if (viewMonth > 12) {
    viewMonth = 1;
    viewYear += 1;
  }
  if (delta > 0 && isFutureMonthView(viewYear, viewMonth)) return;
  datePickerState.viewYear = viewYear;
  datePickerState.viewMonth = viewMonth;
  renderDatePickerPopover();
  positionDatePickerPopover();
}

function selectDatePickerDay(isoDate) {
  const inputId = datePickerState.inputId;
  if (!inputId || !/^\d{4}-\d{2}-\d{2}$/.test(isoDate)) return;
  if (isDatePickerDayDisabled(isoDate, inputId)) {
    if (inputId === 'dateFrom') {
      showDateRangeError('Start date must be before today.');
    } else {
      showDateRangeError('End date cannot be after today.');
    }
    return;
  }
  if (inputId === 'dateFrom') state.dateFrom = isoDate;
  if (inputId === 'dateTo') state.dateTo = isoDate;
  const input = document.getElementById(inputId);
  if (input) input.value = isoDate;
  closeDatePicker();
  syncDatePickerDisplays();
  onManualDateChange();
}

function setDatePickerToday() {
  if (datePickerState.inputId === 'dateFrom') {
    showDateRangeError('Start date must be before today.');
    return;
  }
  const parts = getCalendarPartsInTimeZone(getDashboardTimeZone());
  selectDatePickerDay(isoFromParts(parts.year, parts.month, parts.day));
}

function clearDatePickerField() {
  const inputId = datePickerState.inputId;
  if (!inputId) return;
  state[inputId] = '';
  const input = document.getElementById(inputId);
  if (input) input.value = '';
  closeDatePicker();
  syncDatePickerDisplays();
  onManualDateChange();
}

function handleDatePickerEscape(event) {
  if (event.key === 'Escape') closeDatePicker();
}

function initDatePickers() {
  ensureDatePickerPopover();
  syncDatePickerDisplays();
  if (!datePickerListenersBound) {
    document.addEventListener('keydown', handleDatePickerEscape);
    window.addEventListener('resize', closeDatePicker);
    datePickerListenersBound = true;
  }
}

let lastCustomDateFrom = '';
let lastCustomDateTo = '';

function getPresetDateRange(preset) {
  const timeZone = getDashboardTimeZone();
  const { year, month } = getCalendarPartsInTimeZone(timeZone);

  if (preset === 'month') {
    return formatMonthDateRange(year, month);
  }
  if (preset === 'lastMonth') {
    let lastYear = year;
    let lastMonth = month - 1;
    if (lastMonth < 1) {
      lastMonth = 12;
      lastYear -= 1;
    }
    return formatMonthDateRange(lastYear, lastMonth);
  }
  if (preset === 'year') {
    return { start: `${year}-01-01`, end: `${year}-12-31` };
  }
  return null;
}

function isPresetGeneratedRange(dateFrom, dateTo) {
  if (!dateFrom || !dateTo) return false;
  return ['month', 'lastMonth', 'year'].some((preset) => {
    const range = getPresetDateRange(preset);
    return range && dateFrom === range.start && dateTo === range.end;
  });
}

function saveCustomDateRange() {
  if (!state.dateFrom || !state.dateTo) return;
  if (isPresetGeneratedRange(state.dateFrom, state.dateTo)) return;
  lastCustomDateFrom = state.dateFrom;
  lastCustomDateTo = state.dateTo;
}

function restoreCustomDateRange() {
  if (
    lastCustomDateFrom
    && lastCustomDateTo
    && !isPresetGeneratedRange(lastCustomDateFrom, lastCustomDateTo)
  ) {
    state.dateFrom = lastCustomDateFrom;
    state.dateTo = lastCustomDateTo;
    return;
  }
  state.dateFrom = '';
  state.dateTo = '';
}

function setPreset(preset) {
  if (state.preset === 'custom' && preset !== 'custom') {
    saveCustomDateRange();
  }

  state.preset = preset;
  const timeZone = getDashboardTimeZone();
  const { year, month } = getCalendarPartsInTimeZone(timeZone);

  if (preset === 'all') {
    state.dateFrom = '';
    state.dateTo = '';
    state.dateField = 'createdAt';
  } else if (preset === 'month') {
    const range = formatMonthDateRange(year, month);
    state.dateFrom = range.start;
    state.dateTo = range.end;
    state.dateField = 'lastStatusChangeAt';
  } else if (preset === 'lastMonth') {
    let lastYear = year;
    let lastMonth = month - 1;
    if (lastMonth < 1) {
      lastMonth = 12;
      lastYear -= 1;
    }
    const range = formatMonthDateRange(lastYear, lastMonth);
    state.dateFrom = range.start;
    state.dateTo = range.end;
    state.dateField = 'lastStatusChangeAt';
  } else if (preset === 'year') {
    const range = getPresetDateRange('year');
    state.dateFrom = range.start;
    state.dateTo = range.end;
    state.dateField = 'lastStatusChangeAt';
  } else if (preset === 'custom') {
    state.dateField = 'createdAt';
    restoreCustomDateRange();
  }
}

function updateCustomDateRowVisibility() {
  document.querySelectorAll('#custom-date-row').forEach((row) => {
    row.hidden = state.preset !== 'custom';
  });
}

function updateFilterUi() {
  const dateFrom = document.getElementById('dateFrom');
  const dateTo = document.getElementById('dateTo');
  const adSpend = document.getElementById('adSpend');

  if (dateFrom) dateFrom.value = state.dateFrom || '';
  if (dateTo) dateTo.value = state.dateTo || '';
  if (adSpend) adSpend.value = state.adSpend || '';

  ['status', 'source', 'assignedTo', 'dateField'].forEach((key) => {
    const el = document.getElementById(key);
    if (el) el.value = state[key];
  });

  document.querySelectorAll('[data-preset]').forEach((button) => {
    button.classList.toggle('active', button.dataset.preset === state.preset);
  });

  updateCustomDateRowVisibility();
  syncDatePickerDisplays();
  refreshPipelinePanel();
}

function onManualDateChange() {
  syncFiltersFromDom();

  state.preset = 'custom';
  state.dateField = 'createdAt';

  if (state.dateFrom && state.dateTo && state.dateFrom > state.dateTo) {
    showDateRangeError('From date must be on or before To date.');
    updateFilterUi();
    return;
  }

  if (state.dateFrom && isStartDateDisabled(state.dateFrom)) {
    state.dateFrom = '';
    const input = document.getElementById('dateFrom');
    if (input) input.value = '';
    showDateRangeError('Start date must be before today.');
    updateFilterUi();
    return;
  }

  if (state.dateTo && isFutureDateDisabled(state.dateTo)) {
    state.dateTo = '';
    const input = document.getElementById('dateTo');
    if (input) input.value = '';
    showDateRangeError('End date cannot be after today.');
    updateFilterUi();
    return;
  }

  clearDateRangeError();
  updateFilterUi();

  if (state.dateFrom && state.dateTo) {
    saveCustomDateRange();
    applyDataFilters(false);
  }
}

function onFilterChange(key, value) {
  state[key] = value;
  applyDataFilters(false);
}

async function fetchJson(url, signal) {
  const controller = new AbortController();
  const timeoutId = setTimeout(() => controller.abort(), FETCH_TIMEOUT_MS);

  const abortFromParent = () => controller.abort();
  signal?.addEventListener('abort', abortFromParent);

  try {
    const response = await fetch(url, { signal: controller.signal });
    const data = await response.json().catch(() => ({}));
    if (!response.ok) {
      throw new Error(data.error || `Request failed (${response.status})`);
    }
    return data;
  } catch (error) {
    if (error.name === 'AbortError') {
      throw error;
    }
    throw error;
  } finally {
    clearTimeout(timeoutId);
    signal?.removeEventListener('abort', abortFromParent);
  }
}

async function fetchFacebookMetrics(signal) {
  try {
    const params = new URLSearchParams({ client: facebookClientId });
    if (CLIENT_ACCESS_KEY) params.set('key', CLIENT_ACCESS_KEY);
    return await fetchJson(`/api/facebook-metrics?${params}`, signal);
  } catch (error) {
    if (error.name === 'AbortError') throw error;
    return null;
  }
}

function resolveMarketingPreset() {
  if (['all', 'month', 'lastMonth', 'year'].includes(state.preset)) {
    return state.preset;
  }
  if (state.preset === 'custom' && state.dateFrom && state.dateTo) {
    return 'custom';
  }
  return state.preset;
}

function applyMarketingData(data, fbMetrics) {
  if (!window.MarketingMetrics) return data;
  const marketingPreset = resolveMarketingPreset();
  const useMarketingDateRange = marketingPreset === 'custom';
  const result = window.MarketingMetrics.applyMarketingToDashboard(
    data,
    fbMetrics,
    marketingPreset,
    {
      timeZone: data.account?.timezone || 'Europe/Copenhagen',
      dateFrom: useMarketingDateRange ? state.dateFrom : null,
      dateTo: useMarketingDateRange ? state.dateTo : null,
    },
  );
  if (result.monthlyAdSpend?.length) {
    cachedMonthlyAdSpend = result.monthlyAdSpend;
  }
  if (cachedMonthlyAdSpend?.length) {
    result.monthlyAdSpend = cachedMonthlyAdSpend;
  }
  if (window.MarketingMetrics?.buildMonthlyCostPerLead) {
    result.monthlyCostPerLead = window.MarketingMetrics.buildMonthlyCostPerLead(
      result.monthlyAdSpend,
      result.monthlyLeads || data.monthlyLeads || [],
    );
  }
  return result;
}

async function fetchDashboardData(pipelines, signal, options = {}) {
  const query = buildQuery(pipelines, options);
  const data = await fetchJson(`/api/dashboard${query ? `?${query}` : ''}`, signal);
  return applyChartFieldsCache(data);
}

async function bootstrapDashboardData(signal, options = {}) {
  const params = new URLSearchParams();
  appendTenantParams(params);
  if (options.forceFresh) params.set('fresh', '1');
  const query = params.toString();
  const data = await fetchJson(`/api/dashboard${query ? `?${query}` : ''}`, signal);
  if (data.account?.facebookClientId) {
    facebookClientId = data.account.facebookClientId;
  } else if (data.account?.clientId) {
    facebookClientId = data.account.clientId;
  }
  return applyChartFieldsCache(data);
}

function refreshPipelinePanel() {
  const panel = document.getElementById('pipeline-panel');
  if (!panel) return;
  if (!availablePipelines.length) {
    panel.innerHTML = '<div class="pipeline-note">Sync client data to load pipelines.</div>';
    return;
  }
  panel.innerHTML = renderPipelineSelector(availablePipelines);
}

function selectAllPipelinesAction() {
  selectAllPipelines(availablePipelines);
  refreshPipelinePanel();
}

function clearPipelineSelectionAction() {
  clearPipelineSelection();
  refreshPipelinePanel();
}

function togglePipelineSelectionAction(pipelineId) {
  togglePipelineSelection(pipelineId);
  refreshPipelinePanel();
}

function selectCenhubPipelinesAction() {
  setPipelineSelection(getDefaultPipelineIds(availablePipelines, cachedData?.account?.defaultPipelineIds));
  refreshPipelinePanel();
}

function renderPipelineSelector(pipelines) {
  if (!pipelines.length) {
    return '<div class="pipeline-note">No pipelines found.</div>';
  }

  return `
    <div class="pipeline-actions">
      <button type="button" class="widget-btn ${isAllPipelinesSelected(pipelines) ? 'active' : ''}" onclick="selectAllPipelinesAction()">All pipelines</button>
      <button type="button" class="widget-btn" onclick="selectCenhubPipelinesAction()">Funnel only (Salg + Nye leads)</button>
      <button type="button" class="widget-btn" onclick="clearPipelineSelectionAction()">Clear all</button>
    </div>
    <div class="pipeline-list">
      ${pipelines.map((pipeline) => `
        <label class="pipeline-item">
          <input type="checkbox"
            ${isPipelineSelected(pipeline.id) ? 'checked' : ''}
            onchange="togglePipelineSelectionAction('${pipeline.id}')" />
          <span>${esc(pipeline.name)}</span>
        </label>
      `).join('')}
    </div>
    ${renderPipelineChips(pipelines)}
  `;
}

function renderSelect(id, label, options, value) {
  return `
    <div class="filter-group">
      <label for="${id}">${label}</label>
      <select id="${id}" onchange="onFilterChange('${id}', this.value)">
        ${options.map((option) => `
          <option value="${esc(option.id)}" ${option.id === value ? 'selected' : ''}>${esc(option.name)}</option>
        `).join('')}
      </select>
    </div>
  `;
}

function renderCheckboxGroup(title, group, items, table) {
  const entries = Object.entries(items);
  return `
    <div class="display-group">
      <h3>${title}</h3>
      <div class="widget-actions" style="margin-bottom:10px">
        <button class="widget-btn" onclick="setAllDisplay('${group}', true${table ? `, '${table}'` : ''})">Select all</button>
        <button class="widget-btn" onclick="setAllDisplay('${group}', false${table ? `, '${table}'` : ''})">Clear all</button>
      </div>
      <div class="checkbox-list">
        ${entries.map(([key, label]) => `
          <label class="checkbox-item">
            <input type="checkbox"
              ${isVisible(group, key, table) ? 'checked' : ''}
              onchange="toggleDisplay('${group}', '${key}'${table ? `, '${table}'` : ''})" />
            <span>${label}</span>
          </label>
        `).join('')}
      </div>
    </div>
  `;
}

function renderChartCard(chartId) {
  const definition = window.DashboardCharts?.CHART_DEFINITIONS?.[chartId];
  if (!definition) return '';

  const isCircular = ['pie', 'doughnut', 'polarArea'].includes(definition.defaultType);

  return `
    <div class="card chart-card">
      <div class="section-title">${definition.title}</div>
      ${definition.subtitle ? `<div class="card-sub" style="margin-top:-4px;margin-bottom:12px">${definition.subtitle}</div>` : ''}
      <div class="chart-empty note" style="display:none">${ADMIN_UI ? 'No data for selected filters.' : 'Ingen data for den valgte periode.'}</div>
      <div class="chart-canvas-wrap${isCircular ? ' chart-canvas-wrap--circular' : ''}">
        <canvas id="chart-${chartId}"></canvas>
      </div>
    </div>
  `;
}

function renderChartsSection() {
  if (typeof Chart === 'undefined') {
    return `
      <div class="panel">
        <div class="error-state" style="padding:24px">
          Charts could not load (Chart.js blocked). Check your internet connection or ad blocker.
        </div>
      </div>
    `;
  }

  const visibleCharts = Object.keys(DISPLAY_OPTIONS.charts).filter((chartId) => isVisible('charts', chartId));

  if (!visibleCharts.length) {
    return `
      <div class="panel">
        <div class="empty-section">
          No charts enabled. Open <strong>Display options</strong> and tick items under <strong>Charts</strong>.
        </div>
      </div>
    `;
  }

  return `
    <div class="panel" id="charts-section">
      <div class="charts-panel-title">
        <h2>Charts</h2>
      </div>
      <div class="charts-grid">
        ${visibleCharts.map((chartId) => renderChartCard(chartId)).join('')}
      </div>
    </div>
  `;
}

function renderTable(tableKey, labelColumn, headers, rows, renderCell) {
  const visibleHeaders = headers.filter((header) => isVisible('columns', header.key, tableKey));
  if (!visibleHeaders.length) {
    return '<div class="empty-section">No columns selected for this table.</div>';
  }

  return `
    <table>
      <thead>
        <tr>
          <th>${labelColumn}</th>
          ${visibleHeaders.map((header) => `<th class="${header.align || ''}">${header.label}</th>`).join('')}
        </tr>
      </thead>
      <tbody>
        ${rows.length ? rows.map((row) => `
          <tr>
            <td>${renderCell(row, 'label')}</td>
            ${visibleHeaders.map((header) => `<td class="${header.align || ''}">${renderCell(row, header.key)}</td>`).join('')}
          </tr>
        `).join('') : `<tr><td colspan="${visibleHeaders.length + 1}">Ingen data for valgte filtre.</td></tr>`}
      </tbody>
    </table>
  `;
}

function renderDatePickerTrigger(inputId, label, placeholder) {
  const value = state[inputId] || '';
  const display = formatPickerDisplayLabel(value, placeholder);
  const emptyClass = value ? '' : ' is-empty';
  return `
    <div class="date-picker-field">
      <span class="date-picker-label">${label}</span>
      <button
        type="button"
        class="date-picker-trigger${emptyClass}"
        id="${inputId}-trigger"
        aria-haspopup="dialog"
        aria-controls="date-picker-popover"
        onclick="openDatePicker('${inputId}', this)"
      >
        <span class="date-picker-icon" aria-hidden="true">${ICON_CALENDAR}</span>
        <span class="date-picker-value" id="${inputId}-display">${esc(display)}</span>
      </button>
      <input type="hidden" id="${inputId}" value="${esc(value)}" />
    </div>
  `;
}

function renderCustomDateInputs() {
  return `
    <div class="custom-date-row" id="custom-date-row" ${state.preset !== 'custom' ? 'hidden' : ''}>
      <div class="custom-date-range">
        ${renderDatePickerTrigger('dateFrom', 'From', 'Pick start date')}
        <span class="date-range-separator" aria-hidden="true">→</span>
        ${renderDatePickerTrigger('dateTo', 'To', 'Pick end date')}
      </div>
      <div class="date-range-error" id="date-range-error" hidden></div>
    </div>
  `;
}

function renderPresetControls(inHeader = false) {
  const headerClass = inHeader ? ' header-presets' : '';
  return `
    <div class="preset-controls${inHeader ? ' preset-controls--header' : ''}">
      <div class="preset-btn-row${headerClass}">
        ${renderPresetButtons()}
      </div>
      ${renderCustomDateInputs()}
    </div>
  `;
}

function renderPresetButtons() {
  return `
    <button type="button" class="preset-btn ${state.preset === 'all' ? 'active' : ''}" data-preset="all" onclick="applyPreset('all')">Till date</button>
    <button type="button" class="preset-btn ${state.preset === 'month' ? 'active' : ''}" data-preset="month" onclick="applyPreset('month')">This month</button>
    <button type="button" class="preset-btn ${state.preset === 'lastMonth' ? 'active' : ''}" data-preset="lastMonth" onclick="applyPreset('lastMonth')">Last month</button>
    <button type="button" class="preset-btn ${state.preset === 'year' ? 'active' : ''}" data-preset="year" onclick="applyPreset('year')">This year</button>
    <button type="button" class="preset-btn ${state.preset === 'custom' ? 'active' : ''}" data-preset="custom" onclick="applyPreset('custom')">Custom</button>
  `;
}

function renderAdminFiltersPanel(filterOptions) {
  return `
    <div class="panel" id="admin-filters-panel">
      <div class="panel-title">Data filters</div>
      <div class="filters">
        <div class="filters-row">
          ${renderSelect('source', 'Source', filterOptions.sources, state.source)}
          ${renderSelect('assignedTo', 'Assignee', filterOptions.assignees, state.assignedTo)}
        </div>

        <div class="filters-row actions-row">
          ${renderPresetControls(false)}
          <button type="button" class="refresh-btn primary" id="apply-filters-btn" onclick="applyDataFilters()">Apply data filters</button>
        </div>
      </div>
    </div>
  `;
}

function renderAdminDisplayOptions(displayOpen) {
  return `
    <details class="panel" id="admin-display-panel" ${displayOpen ? 'open' : ''}>
      <summary class="panel-title">Display options</summary>
      <div class="display-grid">
        ${renderCheckboxGroup('KPI cards', 'kpis', DISPLAY_OPTIONS.kpis)}
        ${renderCheckboxGroup('Charts', 'charts', DISPLAY_OPTIONS.charts)}
        ${renderCheckboxGroup('Sections', 'sections', DISPLAY_OPTIONS.sections)}
        ${renderCheckboxGroup('Status items', 'statusItems', DISPLAY_OPTIONS.statusItems)}
        ${renderCheckboxGroup('Source report columns', 'columns', DISPLAY_OPTIONS.columns.sourceReport, 'sourceReport')}
        ${renderCheckboxGroup('Assignee report columns', 'columns', DISPLAY_OPTIONS.columns.assigneeReport, 'assigneeReport')}
        ${renderCheckboxGroup('Pipeline report columns', 'columns', DISPLAY_OPTIONS.columns.pipelineBreakdown, 'pipelineBreakdown')}
      </div>
    </details>
  `;
}

function renderKpiSkeleton() {
  return `
    <div class="kpi-skeleton-grid">
      ${Array.from({ length: 6 }).map(() => '<div class="skeleton-block"></div>').join('')}
    </div>
  `;
}

function clientKpiCopy(adminText, clientText) {
  return IS_CLIENT_VIEW && !IS_PREVIEW ? clientText : adminText;
}

function getAdSpendSubtitle(kpis) {
  if (kpis.adSpendSource !== 'facebook') {
    return 'No ad spend data for this period';
  }

  if (state.preset === 'all') {
    return 'Ad spend';
  }

  const label = kpis.adSpendLabel;
  if (!label || label === 'Custom range' || label === 'Till date') {
    return 'Ad spend';
  }

  const prefix = kpis.adSpendShowAsAvg ? 'Avg ad spend' : 'Ad spend';

  if (/^\d{4}$/.test(label)) {
    return `${prefix} year ${label}`;
  }

  return `${prefix} ${label.toLowerCase()}`;
}

function renderKpiCards(kpis) {
  const cards = [];

  if (isVisible('kpis', 'totalRevenue')) {
    cards.push(`
      <div class="card primary">
        <div class="card-label">Total Revenue</div>
        <div class="card-value">Dkr ${fmtCompact(kpis.totalRevenue)}</div>
        <div class="card-sub">${clientKpiCopy(
          kpis.hasDateFilter
            ? `Won deal value in period (${fmt(kpis.wonOpportunityCount)} won deals)`
            : `Sum of won deal values (${fmt(kpis.wonOpportunityCount)} won deals)`,
          kpis.hasDateFilter
            ? `Vundet omsætning i perioden (${fmt(kpis.wonOpportunityCount)} handler)`
            : `Samlet vundet omsætning (${fmt(kpis.wonOpportunityCount)} handler)`,
        )}</div>
      </div>
    `);
  }
  if (isVisible('kpis', 'adSpend')) {
    const spendSub = getAdSpendSubtitle(kpis);
    cards.push(`
      <div class="card accent">
        <div class="card-label">Ad Spend</div>
        <div class="card-value">${kpis.adSpend > 0 ? `Dkr ${fmtCompact(kpis.adSpend)}` : '—'}</div>
        ${spendSub ? `<div class="card-sub">${spendSub}</div>` : ''}
      </div>
    `);
  }
  if (isVisible('kpis', 'roas')) {
    cards.push(`
      <div class="card accent">
        <div class="card-label">ROAS</div>
        <div class="card-value">${fmtRoas(kpis.roas)}</div>
        <div class="card-sub">Won revenue ÷ ad spend</div>
      </div>
    `);
  }
  if (isVisible('kpis', 'roasDk')) {
    cards.push(`
      <div class="card accent">
        <div class="card-label">ROAS (DK)</div>
        <div class="card-value">${kpis.adSpend > 0 ? `Dkr ${fmtCompact(kpis.roasDk)}` : '—'}</div>
        <div class="card-sub">Won revenue − ad spend</div>
      </div>
    `);
  }
  if (isVisible('kpis', 'poas')) {
    cards.push(`
      <div class="card accent">
        <div class="card-label">POAS</div>
        <div class="card-value">${fmtRoas(kpis.poas)}</div>
        <div class="card-sub">Bundlinje ÷ ad spend</div>
      </div>
    `);
  }
  if (isVisible('kpis', 'poasDk')) {
    cards.push(`
      <div class="card accent">
        <div class="card-label">POAS (DK)</div>
        <div class="card-value">${kpis.adSpend > 0 ? `Dkr ${fmtCompact(kpis.poasDk)}` : '—'}</div>
        <div class="card-sub">Bundlinje − ad spend</div>
      </div>
    `);
  }
  if (isVisible('kpis', 'costPerLead')) {
    cards.push(`
      <div class="card">
        <div class="card-label">Cost per Lead</div>
        <div class="card-value">${kpis.costPerLead > 0 ? `Dkr ${fmtCompact(kpis.costPerLead)}` : '—'}</div>
        <div class="card-sub">Ad spend ÷ new leads in period</div>
      </div>
    `);
  }
  if (isVisible('kpis', 'costPerWonClient')) {
    cards.push(`
      <div class="card">
        <div class="card-label">Cost per Won Client</div>
        <div class="card-value">${kpis.costPerWonClient > 0 ? `Dkr ${fmtCompact(kpis.costPerWonClient)}` : '—'}</div>
        <div class="card-sub">${clientKpiCopy('Ad spend ÷ clients won', 'Annonceforbrug ÷ vundne kunder')}</div>
      </div>
    `);
  }
  if (isVisible('kpis', 'clientsWon')) {
    cards.push(`
      <div class="card">
        <div class="card-label">Clients Won</div>
        <div class="card-value">${fmt(kpis.clientsWon)}</div>
        <div class="card-sub">${clientKpiCopy(
          kpis.hasDateFilter ? 'Unique wins in period' : 'Unique won clients in win pipeline',
          kpis.hasDateFilter ? 'Unikke kunder vundet i perioden' : 'Unikke kunder vundet i alt',
        )}</div>
      </div>
    `);
  }
  if (isVisible('kpis', 'totalLeads')) {
    cards.push(`
      <div class="card">
        <div class="card-label">Total Leads</div>
        <div class="card-value">${fmt(kpis.totalLeads)}</div>
        <div class="card-sub">${kpis.hasDateFilter ? 'New opportunities created in selected period' : kpis.usingCenhubDefaults ? 'New opportunities created in selected period' : 'Opportunities in filter'}</div>
      </div>
    `);
  }
  if (isVisible('kpis', 'totalLeadsValue')) {
    cards.push(`
      <div class="card">
        <div class="card-label">Total Leads Value</div>
        <div class="card-value">Dkr ${fmtCompact(kpis.totalLeadsValue)}</div>
        <div class="card-sub">${kpis.hasDateFilter ? 'Sum of opportunity values in selected period' : kpis.usingCenhubDefaults ? 'Sum of opportunity values for selected pipelines' : 'Sum of all opportunity values'}</div>
      </div>
    `);
  }
  if (isVisible('kpis', 'averageLeadValue')) {
    cards.push(`
      <div class="card">
        <div class="card-label">Average Lead Value</div>
        <div class="card-value">Dkr ${fmtCompact(kpis.averageLeadValue)}</div>
        <div class="card-sub">${kpis.hasDateFilter ? 'Average value per lead in selected period' : kpis.usingCenhubDefaults ? 'All pipeline value ÷ opportunity count' : 'Per opportunity in filter'}</div>
      </div>
    `);
  }
  if (isVisible('kpis', 'conversionRate')) {
    cards.push(`
      <div class="card">
        <div class="card-label">Conversion Rate</div>
        <div class="card-value">${fmtPct(kpis.conversionRate)}</div>
        <div class="card-sub">${clientKpiCopy('Wins ÷ new leads in period', 'Vundne kunder ÷ nye leads i perioden')}</div>
      </div>
    `);
  }
  if (isVisible('kpis', 'openLeads')) {
    cards.push(`
      <div class="card">
        <div class="card-label">Open Leads</div>
        <div class="card-value">${fmt(kpis.openLeads)}</div>
        <div class="card-sub">Opportunities still in pipeline</div>
      </div>
    `);
  }
  if (isVisible('kpis', 'openPipelineValue')) {
    cards.push(`
      <div class="card">
        <div class="card-label">Open Pipeline Value</div>
        <div class="card-value">Dkr ${fmtCompact(kpis.openPipelineValue)}</div>
        <div class="card-sub">Monetary value of open deals</div>
      </div>
    `);
  }
  if (isVisible('kpis', 'averageWonDealSize')) {
    cards.push(`
      <div class="card">
        <div class="card-label">Avg Won Deal Size</div>
        <div class="card-value">Dkr ${fmtCompact(kpis.averageWonDealSize)}</div>
        <div class="card-sub">${clientKpiCopy(
          `Won revenue ÷ won deals (${fmt(kpis.wonOpportunityCount)})`,
          `Gns. vundet handel (${fmt(kpis.wonOpportunityCount)} handler)`,
        )}</div>
      </div>
    `);
  }
  if (isVisible('kpis', 'totalBundlinje')) {
    cards.push(`
      <div class="card">
        <div class="card-label">Total Bundlinje</div>
        <div class="card-value">Dkr ${fmtCompact(kpis.totalBundlinje)}</div>
        <div class="card-sub">Bundlinje on won deals</div>
      </div>
    `);
  }

  if (!cards.length) {
    return IS_ADMIN
      ? '<div class="empty-section">No KPI cards selected. Use the display options below.</div>'
      : '<div class="empty-section">No KPI data for selected period.</div>';
  }

  return `<div class="kpi-grid">${cards.join('')}</div>`;
}

function renderStatusBreakdown(statusBreakdown) {
  const items = Object.entries(DISPLAY_OPTIONS.statusItems)
    .filter(([key]) => isVisible('statusItems', key))
    .map(([key, label]) => `
      <div class="status-item">
        <div class="name">${label}</div>
        <div class="value">${fmt(statusBreakdown[key])}</div>
      </div>
    `);

  if (!items.length) {
    return '<div class="empty-section">No status items selected.</div>';
  }

  return `<div class="status-grid">${items.join('')}</div>`;
}

function renderMetricsChangeBanner(data) {
  const changedAt = data.account?.metricsModel?.changedAt;
  if (!changedAt) return '';
  const ageMs = Date.now() - new Date(changedAt).getTime();
  if (ageMs > 7 * 24 * 60 * 60 * 1000) return '';
  const version = data.account?.metricsModel?.version || 1;
  return `
    <div class="metrics-change-banner">
      Metrics model updated on ${new Date(changedAt).toLocaleString('en-GB')} (v${version}).
      Revenue, clients won, and won-revenue charts now use: ${esc(data.account.metricsModel.winSourceLabel || data.account.metricsModel.label)}.
    </div>
  `;
}

function renderDashboardContent(data) {
  const { kpis, statusBreakdown, sourceReport, assigneeReport, pipelines, filters } = data;
  const showStatus = isVisible('sections', 'statusBreakdown');

  return `
    ${renderMetricsChangeBanner(data)}
    ${renderKpiCards(kpis)}

    ${renderChartsSection()}

    ${showStatus ? `
      <div class="card">
        <div class="section-title">Opportunity Status (Cards)</div>
        ${renderStatusBreakdown(statusBreakdown)}
      </div>
    ` : ''}

    ${isVisible('sections', 'sourceReport') ? `
      <div class="card">
        <div class="section-title">Lead Source Report</div>
        ${renderTable(
          'sourceReport',
          'Source',
          [
            { key: 'totalLeads', label: 'Total leads', align: 'num' },
            { key: 'totalValue', label: 'Total values', align: 'num' },
            { key: 'open', label: 'Open', align: 'num' },
            { key: 'won', label: 'Won', align: 'num' },
            { key: 'lost', label: 'Lost', align: 'num' },
            { key: 'abandoned', label: 'Abandoned', align: 'num' },
            { key: 'winPct', label: 'Win %', align: 'num' },
          ],
          sourceReport,
          (row, key) => {
            if (key === 'label') return esc(row.source);
            if (key === 'totalValue') return `Dkr ${fmt(row.totalValue)}`;
            if (key === 'winPct') return fmtPct(row.winPct);
            return fmt(row[key]);
          }
        )}
      </div>
    ` : ''}

    ${isVisible('sections', 'assigneeReport') || isVisible('sections', 'pipelineBreakdown') ? `
      <div class="section-grid">
        ${isVisible('sections', 'assigneeReport') ? `
          <div class="card">
            <div class="section-title">Leads Closed by Assignee</div>
            ${renderTable(
              'assigneeReport',
              'Assignee',
              [
                { key: 'won', label: 'Won', align: 'num' },
                { key: 'totalLeads', label: 'Total leads', align: 'num' },
                { key: 'wonValue', label: 'Won revenue', align: 'num' },
                { key: 'totalValue', label: 'Total value', align: 'num' },
              ],
              assigneeReport,
              (row, key) => {
                if (key === 'label') return esc(row.assigneeName);
                if (key === 'wonValue' || key === 'totalValue') return `Dkr ${fmt(row[key])}`;
                return fmt(row[key]);
              }
            )}
          </div>
        ` : ''}
        ${isVisible('sections', 'pipelineBreakdown') ? `
          <div class="card">
            <div class="section-title">Pipeline Breakdown</div>
            ${renderTable(
              'pipelineBreakdown',
              'Pipeline',
              [
                { key: 'count', label: 'Leads', align: 'num' },
                { key: 'won', label: 'Won', align: 'num' },
                { key: 'monetary', label: 'Value', align: 'num' },
                { key: 'profit', label: 'Bundlinje', align: 'num' },
                { key: 'wonValue', label: 'Won revenue', align: 'num' },
              ],
              pipelines,
              (row, key) => {
                if (key === 'label') return esc(row.name);
                if (key === 'monetary' || key === 'profit' || key === 'wonValue') return `Dkr ${fmt(row[key])}`;
                return fmt(row[key]);
              }
            )}
          </div>
        ` : ''}
      </div>
    ` : ''}

    ${IS_ADMIN ? `
    <div class="note">
      ${kpis.usingCenhubDefaults ? 'Till-date Total Leads uses deduped opportunities from account pipeline defaults. ' : ''}
      Active filters: source=${filters.source}, assignee=${filters.assignedTo}, dates=${formatActiveDateFilter(filters)}.
    </div>
    ` : ''}
    <div class="brand-footer">
      Dashboard by Cenhub
      · Holstebro
    </div>
  `;
}

function updateDashboardContent(data) {
  if (IS_ADMIN) {
    const filtersPanel = document.getElementById('admin-filters-panel');
    if (filtersPanel) {
      filtersPanel.outerHTML = renderAdminFiltersPanel(data.filterOptions || {
        pipelines: [],
        statuses: [],
        sources: [],
        assignees: [],
        dateFields: [],
      });
    }
    const displayPanel = document.getElementById('admin-display-panel');
    if (displayPanel) {
      const displayOpen = Boolean(displayPanel.open);
      displayPanel.outerHTML = renderAdminDisplayOptions(displayOpen);
    }
  }

  const content = document.getElementById('dashboard-content');
  if (content) {
    content.innerHTML = renderDashboardContent(data);
    mountCharts(data);
  }
}

function renderDashboard(data) {
  const dashboard = document.getElementById('dashboard');
  const { filterOptions, account = {} } = data;
  const displayOpen = document.querySelector('details.panel')?.open;
  const accountName = account.accountName || 'Dashboard';
  if (IS_CLIENT_VIEW && account.accountName) {
    document.title = `${account.accountName} · Cenhub Dashboard`;
  }

  dashboard.innerHTML = `
    ${renderBrandTopbar(IS_ADMIN ? '<a class="admin-topbar-link" href="/admin">Admin hub</a>' : '')}
    ${wrapDashboardShell(`
    ${IS_ADMIN_CLIENT ? `
    <div id="setup-panel-mount"></div>
    <details class="panel admin-preview-section"${document.querySelector('.admin-preview-section')?.open ? ' open' : ''}>
      <summary>${ICON_CHART} Dashboard preview <span style="color:var(--text-soft);font-weight:500">· advanced filters</span><span class="summary-chevron">${ICON_CHEVRON}</span></summary>
      ${renderAdminFiltersPanel(filterOptions)}
      ${renderAdminDisplayOptions(displayOpen)}
      <div class="content-area" id="dashboard-content">
        ${renderDashboardContent(data)}
      </div>
    </details>
    ` : `
    <div class="page-hero">
      <div class="header">
        <div>
          <h1>${esc(accountName)}</h1>
          <p>Performance dashboard · Pipeline & omsætning</p>
        </div>
        ${IS_ADMIN ? '' : `
        <div class="header-actions header-actions--client">
          ${renderPresetControls(true)}
        </div>
        `}
      </div>
    </div>
    ${IS_ADMIN ? renderAdminFiltersPanel(filterOptions) : ''}
    ${IS_ADMIN ? renderAdminDisplayOptions(displayOpen) : ''}
    <div class="content-area" id="dashboard-content">
      ${renderDashboardContent(data)}
    </div>
    `}
    `)}
  `;

  if (IS_ADMIN_CLIENT) loadSetupAccount();
  initDatePickers();
}

let isFetching = false;
let pendingRefetch = false;
let fetchGeneration = 0;
let activeFetchController = null;
let fetchStartedAt = 0;
const FETCH_TIMEOUT_MS = 90000;

function setPresetButtonsDisabled(disabled) {
  document.querySelectorAll('[data-preset]').forEach((button) => {
    button.disabled = disabled;
  });
}

function resetFetchUiState() {
  isFetching = false;
  setPresetButtonsDisabled(false);
  const applyBtn = document.getElementById('apply-filters-btn');
  if (applyBtn) {
    applyBtn.disabled = false;
    applyBtn.textContent = 'Apply data filters';
  }
}

function cancelActiveFetch() {
  if (activeFetchController) {
    activeFetchController.abort();
    activeFetchController = null;
  }
}

function canReuseBootstrapDashboard(bootstrapData) {
  return Boolean(
    bootstrapData?.kpis
    && usesClientPipelineDefaults()
    && !state.dateFrom
    && !state.dateTo
    && state.status === 'all'
    && state.source === 'all'
    && state.assignedTo === 'all',
  );
}

async function loadDashboard(refetch = true, options = {}) {
  const { background = false, forceFresh = false } = options;
  const shouldFetchFresh = Boolean(forceFresh) || (refetch && cachedData && needsFreshData());
  const dashboard = document.getElementById('dashboard');

  if (isFetching && (refetch || !cachedData)) {
    cancelActiveFetch();
    fetchGeneration += 1;
    pendingRefetch = false;
    resetFetchUiState();
  } else if (isFetching) {
    if (refetch) pendingRefetch = true;
    return;
  }

  const hasLayout = Boolean(document.getElementById('dashboard-content'));
  const applyBtn = document.getElementById('apply-filters-btn');

  if (refetch || !cachedData) {
    const generation = ++fetchGeneration;
    activeFetchController = new AbortController();
    const signal = activeFetchController.signal;
    isFetching = true;
    fetchStartedAt = Date.now();

    if (!hasLayout) {
      dashboard.innerHTML = `
        ${renderBrandTopbar(IS_ADMIN ? '<a class="admin-topbar-link" href="/admin">Admin hub</a>' : '')}
        ${wrapDashboardShell(`
          <div class="loading-state">
            <div class="spinner"></div>
            ${LOADING_MSG}
          </div>
        `)}`;
    } else if (!background) {
      const content = document.getElementById('dashboard-content');
      if (content) content.innerHTML = renderKpiSkeleton();
      if (applyBtn) {
        applyBtn.disabled = true;
        applyBtn.textContent = 'Loading...';
      }
      setPresetButtonsDisabled(true);
    }

    try {
      let bootstrapData = null;
      if (!availablePipelines.length) {
        bootstrapData = await bootstrapDashboardData(signal);
        if (generation !== fetchGeneration) return;
        availablePipelines = bootstrapData.filterOptions.pipelines || [];
        ensurePipelineDefaults(availablePipelines, bootstrapData.account?.defaultPipelineIds);
      }

      const pipelineSelectionReady = ensurePipelineSelectionBeforeFetch();
      if (!pipelineSelectionReady) {
        throw new Error('Select at least one pipeline.');
      }

      const reuseBootstrap = canReuseBootstrapDashboard(bootstrapData) && !shouldFetchFresh;
      let data;
      let fbMetrics;
      if (reuseBootstrap) {
        [fbMetrics, data] = await Promise.all([
          fetchFacebookMetrics(signal),
          Promise.resolve(bootstrapData),
        ]);
      } else {
        [data, fbMetrics] = await Promise.all([
          fetchDashboardData(availablePipelines, signal, { forceFresh: shouldFetchFresh }),
          fetchFacebookMetrics(signal),
        ]);
      }
      if (generation !== fetchGeneration) return;
      cachedFacebookMetrics = fbMetrics;
      cachedData = applyMarketingData(data, fbMetrics);
      if (cachedData.account?.facebookClientId) {
        facebookClientId = cachedData.account.facebookClientId;
      } else if (cachedData.account?.clientId) {
        facebookClientId = cachedData.account.clientId;
      }
      availablePipelines = cachedData.filterOptions.pipelines || availablePipelines;
      ensurePipelineDefaults(availablePipelines, cachedData?.account?.defaultPipelineIds);
      lastFetchedAt = cachedData.cachedAt
        ? new Date(cachedData.cachedAt).getTime()
        : Date.now();
    } catch (error) {
      if (generation !== fetchGeneration) return;
      if (error.name === 'AbortError') {
        if (!hasLayout) {
          dashboard.innerHTML = `
            ${renderBrandTopbar(IS_ADMIN ? '<a class="admin-topbar-link" href="/admin">Admin hub</a>' : '')}
            ${wrapDashboardShell(`
              <div class="error-state">
                <div>Fejl ved hentning af data</div>
                <div style="margin-top:8px;font-size:12px;color:#666">Request timed out. Prøv igen.</div>
                <button class="refresh-btn primary" onclick="loadDashboard(true)">${RETRY_MSG}</button>
              </div>
            `)}`;
        }
        return;
      }
      if (IS_ADMIN_CLIENT && hasLayout) {
        const content = document.getElementById('dashboard-content');
        if (content) {
          content.innerHTML = `
            <div class="note admin-setup-placeholder">
              ${esc(error.message)}
              <div style="margin-top:12px">
                <button type="button" class="refresh-btn primary" onclick="loadDashboard(true)">${RETRY_MSG}</button>
              </div>
            </div>`;
        }
      } else if (!hasLayout) {
        dashboard.innerHTML = `
          ${renderBrandTopbar(IS_ADMIN ? '<a class="admin-topbar-link" href="/admin">Admin hub</a>' : '')}
          ${wrapDashboardShell(`
            <div class="error-state">
              <div>Fejl ved hentning af data</div>
              <div style="margin-top:8px;font-size:12px;color:#666">${esc(error.message)}</div>
              <button class="refresh-btn primary" onclick="loadDashboard(true)">${RETRY_MSG}</button>
            </div>
          `)}`;
      } else if (applyBtn) {
        applyBtn.textContent = 'Apply failed - try again';
      }
      return;
    } finally {
      if (generation === fetchGeneration) {
        activeFetchController = null;
        resetFetchUiState();
      }
      if (pendingRefetch) {
        pendingRefetch = false;
        loadDashboard(true);
      }
    }

    if (generation !== fetchGeneration) return;
  }

  try {
    if (hasLayout) {
      cachedData = applyMarketingData(cachedData, cachedFacebookMetrics);
      updateDashboardContent(cachedData);
      updateFilterUi();
    } else {
      renderDashboard(cachedData);
      mountCharts(cachedData);
    }
  } catch (error) {
    resetFetchUiState();
    dashboard.innerHTML = `
      ${renderBrandTopbar(IS_ADMIN ? '<a class="admin-topbar-link" href="/admin">Admin hub</a>' : '')}
      ${wrapDashboardShell(`
        <div class="error-state">
          <div>Fejl ved visning af dashboard</div>
          <div style="margin-top:8px;font-size:12px;color:#666">${esc(error.message)}</div>
          <button class="refresh-btn primary" onclick="loadDashboard(true)">${RETRY_MSG}</button>
        </div>
      `)}
    `;
  }
}

function syncFiltersFromDom() {
  ['status', 'source', 'assignedTo', 'dateField'].forEach((key) => {
    const el = document.getElementById(key);
    if (el) state[key] = el.value;
  });

  const adSpend = document.getElementById('adSpend');
  if (adSpend) state.adSpend = adSpend.value;

  if (state.preset === 'custom') {
    const dateFrom = document.getElementById('dateFrom');
    const dateTo = document.getElementById('dateTo');
    if (dateFrom) state.dateFrom = dateFrom.value;
    if (dateTo) state.dateTo = dateTo.value;
    state.dateField = 'createdAt';
  }
}

function hasPartialDateRange() {
  return Boolean((state.dateFrom && !state.dateTo) || (!state.dateFrom && state.dateTo));
}

function applyPreset(preset) {
  clearDateRangeError();
  closeDatePicker();
  setPreset(preset);
  updateFilterUi();
  if (preset === 'custom') {
    const trigger = document.getElementById('dateFrom-trigger');
    if (trigger) openDatePicker('dateFrom', trigger);
    return;
  }
  applyDataFilters(false);
}

function applyDataFilters(syncFromDom = true) {
  if (syncFromDom) syncFiltersFromDom();

  if (state.preset === 'custom') {
    if (hasPartialDateRange()) {
      showDateRangeError('Select both From and To dates.');
      return;
    }

    if (state.dateFrom && state.dateTo && state.dateFrom > state.dateTo) {
      showDateRangeError('From date must be on or before To date.');
      return;
    }

    if (state.dateFrom && isStartDateDisabled(state.dateFrom)) {
      showDateRangeError('Start date must be before today.');
      return;
    }

    if (state.dateTo && isFutureDateDisabled(state.dateTo)) {
      showDateRangeError('End date cannot be after today.');
      return;
    }
  }

  clearDateRangeError();

  if (!state.pipelineIds.length && availablePipelines.length) {
    ensurePipelineDefaults(availablePipelines, cachedData?.account?.defaultPipelineIds);
  }

  if (!state.pipelineIds.length) {
    return;
  }

  loadDashboard(true);
}

async function initDashboardApp() {
  if (IS_LOGIN_PAGE) {
    renderLoginPage();
    return;
  }

  if (IS_ADMIN_HUB) {
    loadAdminHub();
    return;
  }

  if (IS_TEAM_PAGE) {
    loadTeamPage();
    return;
  }

  try {
    tenantParams = await resolveTenantParams();
  } catch (error) {
    document.getElementById('dashboard').innerHTML = `
      <div class="error-state" style="padding:24px">${esc(error.message)}</div>`;
    return;
  }

  if (IS_ADMIN_CLIENT) {
    await initAdminClientPage();
    return;
  }

  ensureChartsVisible();
  loadDashboard(true);
  setInterval(() => {
    loadDashboard(true, { background: true });
  }, DATA_REFRESH_MS);
}

initDashboardApp();

document.addEventListener('click', () => {
  closeCardMenus();
  closeStaffUserMenu();
});

document.addEventListener('visibilitychange', () => {
  if (document.visibilityState !== 'visible') return;
  if (isFetching && Date.now() - fetchStartedAt > FETCH_TIMEOUT_MS) {
    cancelActiveFetch();
    fetchGeneration += 1;
    resetFetchUiState();
  }
  if (!IS_ADMIN_HUB && cachedData && needsFreshData()) {
    loadDashboard(true, { background: true, forceFresh: true });
  }
});
