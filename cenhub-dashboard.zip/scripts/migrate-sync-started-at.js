#!/usr/bin/env node
require('dotenv').config();

const fs = require('fs');
const path = require('path');

async function main() {
  if (!process.env.DATABASE_URL) {
    console.error('DATABASE_URL is not set.');
    process.exit(1);
  }

  const sql = fs.readFileSync(
    path.join(__dirname, '..', 'db', 'migrate-sync-started-at.sql'),
    'utf8',
  );
  const { neon } = require('@neondatabase/serverless');
  const query = neon(process.env.DATABASE_URL);
  await query(sql);
  console.log('Applied sync_started_at migration.');
}

main().catch((error) => {
  console.error(error.message || error);
  process.exit(1);
});
